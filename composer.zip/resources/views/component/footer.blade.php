<footer id="footer" class="footer">
	<div class="container">
		
	</div>
	<div class="container">
		<div class="row">
			<div class="col-md-3 text-center" style="padding:15px;">
				<a href="/" ><img src="/img/logo.png" height="70"></a>
			</div>
			<div class="col-md-9 menu">
				<div class="row">
					<div class="col-sm-4 text-center">
						<a href="/ticket">Vé máy bay</a>
					</div>
					<div class="col-sm-4 text-center">
						<a href="/about-us">Về chúng tôi</a> 

					</div>
					<div class="col-sm-4 text-center">
						<a href="/contact-us">Liên hệ với chúng tôi</a>
					</div>
				</div>
				<br class="hidden-xs">
				<div class="row">
					<div class="col-sm-4 text-center">
						<a href="/payment">Thanh toán</a>
					</div>
					<div class="col-sm-4 text-center">
						<a href="/agency">Lợi ích của đại lý cấp 2</a>
					</div>
					<div class="col-sm-4 text-center">
						<a href="/agency">Trở thành đại lý cấp 2</a>
					</div>
				</div>
			</div>
		</div>
		<hr class="no-margin">
		<div class="row">
			<div class="col-md-12 text-center" style="padding: 10px;">
				<p class="text-white"><small >CÔNG TY TNHH XÚC TIẾN THƯƠNG MẠI TIẾN PHONG</small></p>
				<small><a href="https://facebook.com/thangkubom742" target="_blank">Design and make by Vu Thanh Vien</a></small>
				<br>
			</div>
		</div>
	</div>
</footer>
