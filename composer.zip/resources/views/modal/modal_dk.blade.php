
<div  class="modal fade modal-dk" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Điều kiện về hành lý và giá vé</h4>
        </div>
        <div class="modal-body">
            <div class="ticket-detail-other-info">

                <p>Đối với những chuyến bay, quý khách được mang 7kg hành ký kèm theo, nếu hơn hãy liên hệ với cty Tiền Phong để được tư vấn thêm</p>

            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Đóng</button>
        </div>
    </div>
</div>

