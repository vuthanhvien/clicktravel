@extends('admin.layout')

@section('content')

<div class="container-fluid">
	<div class="row">
		<div class="col-md-12 text-center">
		<br>
		<br>
		<br>
		<br>
		<br>
		<p style="font-size: 60px; font-weight: 700; line-height: 1">404 <br> <small style="color: #999; font-size: 24px"> Không tìm thấy nội dung</small></p>

		<br>
		<p>Chúng tôi không tìm thấy trang đích của bạn, xin hãy thử lại</p>
		<a class="btn" href="/admin"><i class="fa fa-chevron-left"></i> Quay về bảng điều khiển </a>

		</div>

		
	</div>
</div>
@endsection