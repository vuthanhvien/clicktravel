<?php 

return [
		'g_username' 	=> 'galileo',
		'g_password' 	=> '*#gl1203@#NQM',
		'h_user' 		=> 'nqminh',
		'h_pass' 		=> 'galileo',
		'h_pcc' 		=> '082P',
		// 'g_username' 	=> 'galileo',
		// 'g_password' 	=> '*#gl1203@#NQM',
		// 'h_user' 		=> 'ZPG',
		// 'h_pass' 		=> 'HCM2017',
		// 'h_pcc' 		=> 'g1400037',
];