<?php 

return [
		// 'g_username' 	=> 'galileo',
		// 'g_password' 	=> '*#gl1203@#NQM',
		// 'h_user' 		=> 'nqminh',
		// 'h_pass' 		=> 'galileo',
		// 'h_pcc' 			=> '082P',
		'g_username' 	=> 'galileo',
		'g_password' 	=> '*#gl1203@#NQM',
		'h_user' 		=> 'DAITIENPHONGAPI',
		'h_pass' 		=> 'dAITIEnPh0ngAPI',
		'h_pcc' 		=> '5R54',

];