<?php $__env->startSection('content'); ?>

<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
										<div class="row">
						<div class="col-xs-5"><h4 class="title">Mã khuyến mãi</h4>
						</div>
						<div class="col-xs-7 text-right">
							<span>
								<ul class="pagination pull-right" style="margin:0; color: #555">
									<?php if( $promotions->currentPage() != 1): ?> 
										<li><a href="/admin/promotion?s=<?php echo e($search); ?>&page=1">Trang đầu</a></li>
									<?php else: ?>
										<li class="disabled"><a href="/admin/promotion?s=<?php echo e($search); ?>&page=1">Trang đầu</a></li>

									<?php endif; ?>
									<?php if( $promotions->currentPage() == $promotions->lastPage()  && $promotions->currentPage() > 4): ?>
										<li><a href="/admin/promotion?s=<?php echo e($search); ?>&page=<?php echo e($promotions->currentPage() - 4); ?>"><?php echo e($promotions->currentPage() - 4); ?></a></li>
									<?php endif; ?>
									<?php if(( $promotions->currentPage() == $promotions->lastPage() - 1 ||  $promotions->currentPage() == $promotions->lastPage()) &&   $promotions->currentPage() > 3): ?> 
										<li><a href="/admin/promotion?s=<?php echo e($search); ?>&page=<?php echo e($promotions->currentPage() - 3); ?>"><?php echo e($promotions->currentPage() - 3); ?></a></li>
									<?php endif; ?>
									<?php if( $promotions->currentPage() > 2): ?> 
										<li><a href="/admin/promotion?s=<?php echo e($search); ?>&page=<?php echo e($promotions->currentPage() - 2); ?>"><?php echo e($promotions->currentPage() - 2); ?></a></li>
									<?php endif; ?>
									<?php if( $promotions->currentPage() > 1): ?> 
										<li><a href="/admin/promotion?s=<?php echo e($search); ?>&page=<?php echo e($promotions->currentPage() - 1); ?>"><?php echo e($promotions->currentPage() - 1); ?></a></li>
									<?php endif; ?>

									<li  class="active"><a  href="#"><?php echo e($promotions->currentPage()); ?></a></li>

									<?php if( $promotions->currentPage() < $promotions->lastPage()): ?> 
										<li><a href="/admin/promotion?s=<?php echo e($search); ?>&page=<?php echo e($promotions->currentPage() + 1); ?>"><?php echo e($promotions->currentPage() + 1); ?></a></li>
									<?php endif; ?>
									<?php if( $promotions->currentPage() < $promotions->lastPage() - 1 ): ?> 
										<li><a href="/admin/promotion?s=<?php echo e($search); ?>&page=<?php echo e($promotions->currentPage() + 2); ?>"><?php echo e($promotions->currentPage() + 2); ?></a></li>
									<?php endif; ?>
									<?php if(( $promotions->currentPage() == 2 ||  $promotions->currentPage() == 1) && $promotions->lastPage() > 3 ): ?>
										<li><a href="/admin/promotion?s=<?php echo e($search); ?>&page=<?php echo e($promotions->currentPage() + 3); ?>"><?php echo e($promotions->currentPage() + 3); ?></a></li>
									<?php endif; ?>
									<?php if( $promotions->currentPage() == 1 && $promotions->lastPage() > 4): ?> 
										<li><a href="/admin/promotion?s=<?php echo e($search); ?>&page=<?php echo e($promotions->currentPage() + 4); ?>"><?php echo e($promotions->currentPage() + 4); ?></a></li>
									<?php endif; ?>
									<?php if( $promotions->currentPage() != $promotions->lastPage() ): ?> 
										<li><a href="/admin/promotion?s=<?php echo e($search); ?>&page=<?php echo e($promotions->lastPage()); ?>">Trang cuối</a></li>
									<?php else: ?>
										<li class="disabled"><a href="/admin/promotion?s=<?php echo e($search); ?>&page=<?php echo e($promotions->lastPage()); ?>">Trang cuối</a></li>
									<?php endif; ?>
								</ul>
								<style type="text/css">
									.pagination a{
										color: #555;
									}
									.card [data-background-color] a{
										color: initial;
									}
									.pagination li.active a{
										color: white;
									}
									.pagination li.disabled a{
										pointer-events: none;
									}
									.pagination li.disabled a{
										color: #ccc;
									}
								</style>
							</span>
							<form action="/admin/promotion">
								<div class="pull-right" style="position: relative;" >
									<input placeholder="Tìm kiếm" name="s" value="<?php echo e($search); ?>" style="color:#555; padding-left: 15px;   height: 34px;border: 0;border-radius: 5px;margin-right: 17px;" onkeydown="if (event.keyCode == 13) { this.form.submit(); return false; }">
									<i style="position: absolute;color: #555;right: 25px;top: 10px;" class="fa fa-search"></i>
								</div>
							</form>
						</div>
					</div>
				</div>
				<div class="card-content table-responsive">
					<table class="table">
						<thead class="text-primary">
							<th>Mã</th>
							<th>Loại</th>
							<th>Gía</th>
							<th>Trạng thái</th>
							<th>Email sử dụng</th>
							<th></th>
						</thead>
						<tbody>
						<?php $__currentLoopData = $promotions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promotion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><p><?php echo e($promotion->key); ?></p></td>
								<td><?php if($promotion->type == 'one'): ?> Sử dụng 1 lần <?php else: ?> Sử dụng nhiều lần <?php endif; ?></td>
								<td class="money"><?php echo e($promotion->price); ?></td>
								<td><?php if($promotion->status == 'new'): ?> Mới tạo (<?php echo e($promotion->created_at); ?>) <?php endif; ?>
									<?php if($promotion->status == 'expire'): ?> Hết hạn <?php endif; ?>
									<?php if($promotion->status == 'used'): ?> Đã được sử dụng <?php endif; ?>
									</td>
								<td><?php echo e($promotion->email_used); ?></td>
								<td class="no-padding"><button class="btn btn-danger btn-xs"   data-toggle="modal" data-target="#promotion_delete" onclick="add_delete('<?php echo e($promotion->key); ?>')">Xóa</button></td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>

				</div>
			</div>
			<span><a class="btn btn-success"   data-toggle="modal" data-target="#promotion_new" ><i class="fa fa-plus"></i> &nbsp; &nbsp; Tạo khuyến mãi mới</a></span>
		</div>

		
	</div>
</div>
<script type="text/javascript">
	<?php if(isset($_REQUEST['error']) || isset($_REQUEST['success'])): ?>
	$('#promotion_new').modal('show');
	<?php endif; ?>

	function add_delete(key){
		$('#delete_id').val(key);

	}
</script>
<style type="text/css">
	.table td{
		font-size: 14px;
	}
</style>
<?php $__env->stopSection(); ?>
<div id="promotion_new" class="modal fade <?php if(isset($_REQUEST['error']) || isset($_REQUEST['success'])): ?> in <?php endif; ?>" role="dialog">
	<form action="/admin/promotion_save" method="POST">
		<div class="modal-dialog">
                <?php echo e(csrf_field()); ?>


			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Khuyến mãi mới</h4>
				</div>
				<div class="modal-body">
					<div class="row">
						<div class="col-md-8 col-md-offset-2">
							<div class="form-group label-floating ">
								<label class="control-label">Mã khuyến mãi (Viết liền, không dấu)</label>
								<input type="text" class="form-control" name="key" required <?php if(isset($_GET['code']) ): ?>  value="<?php echo e($_GET['code']); ?>"  <?php endif; ?>>
								<span class="material-input"></span>
							</div>
						</div>

						<div class="col-md-8 col-md-offset-2">
							<div class="form-group label-floating ">
								<label class="control-label">Giá trị (VND)</label>
								<input type="number" class="form-control" name="price" required> 
								<span class="material-input"></span>
							</div>
						</div>
						<div class="col-md-8 col-md-offset-2">
							<div class="form-group label-floating ">
								<label class="control-label">Loại</label>
								<select type="number" class="form-control" name="type" required> 
									<option value="one">Sử dụng 1 lần</option>
									<option value="muti">Sử dụng nhiều lần</option>
								</select>
								<span class="material-input"></span>
							</div>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-success" >Tạo</button>
					<button type="button" class="btn btn-default" data-dismiss="modal">Hủy</button>
				</div>
			</div>
		</form>
	</div>
</div>

<div id="promotion_delete" class="modal fade" role="dialog">
	<form action="/admin/promotion_delete" method="POST">
                <?php echo e(csrf_field()); ?>


		<div class="modal-dialog">

			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Khuyến mãi mới</h4>
				</div>
				<div class="modal-body">
					<div class="row">
						<div class="col-md-8 col-md-offset-2">
							<label class="control-label">Mã khuyến mãi (Viết liền, không dấu)</label>
							<input type="text" class="form-control" name="key" required id="delete_id">
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-danger">Xóa</button>
					<button type="button" class="btn btn-default" data-dismiss="modal">Hủy</button>
				</div>
			</div>
		</form>
	</div>
</div>


<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>