<?php $__env->startSection('title'); ?>
Thông tin chuyến bay
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <td align="" valign="top" width="100%" style="background-color: #ffffff;  border-top: 1px solid #e5e5e5; border-bottom: 1px solid #e5e5e5;">
        <table cellpadding="0" cellspacing="0" width="100%" class="w320 detail" >
			<tr>
				<td style="border: 0 !important; padding: 15px">
					<table width="100%">
						<tr>
							<td style="border: 0!important" width="60%" colspan="2">
								<br>
								<p>Xin chào <?php echo e($ticket->contact_name); ?> (<?php echo e($ticket->contact_email); ?>) </p>
								<p>Công ty TNHH Tien Phong xin gửi quý khách thông tin chuyến bay mã đặt chỗ <strong><?php echo e($ticket->seat_id); ?></strong></p>
							</td>
							<td  style="border: 0!important; text-align: center;"  colspan="2" >
								<br>
								<br>
								<p><a href="<?php echo e(url('/')); ?>/ticket/info/<?php echo e(base64_encode('ticket_id='.$ticket->id)); ?>" style="    color: #ffffff;
								    background: #009fe3;
								    border: none;
								    height: 40;
								    padding: 15px 30px;
								    border-radius: 5px;">Xem chi tiết</a></p>
								<br>
							</td>
						</tr>
						<tr>
							<td colspan="4" style="border: 0!important"> 
							</td>
						</tr>
						<tr style="background-color: #009fe3; border: 1px solid #eee; height: 45px; color:white;">
							<td colspan="4"  style="border: 0!important; color:white "><h3>Chi tiết liên lạc</h3></td>
						</tr>
						<tr>
							<td width="30%" style="text-align:left">
								<p>&nbsp;&nbsp;&nbsp;Tên</p>
								<p width="50%">&nbsp;&nbsp;&nbsp;Email</p>
								<p width="20%">&nbsp;&nbsp;&nbsp;Điện thoại</p>
								<p width="20%">&nbsp;&nbsp;&nbsp;Địa chỉ</p>
							</td>
							<td colspan="3" style="text-align:left">
								<p>&nbsp;&nbsp;&nbsp;<?php echo e($ticket->contact_name); ?></p>
								<p width="50%">&nbsp;&nbsp;&nbsp;<?php echo e($ticket->contact_email); ?></p>
								<p width="20%">&nbsp;&nbsp;&nbsp;<?php echo e($ticket->contact_phone); ?></p>
								<p width="20%">&nbsp;&nbsp;&nbsp;<?php echo e($ticket->contact_address); ?></p>
							</td>
						</tr>
					</table>

					<table width="100%">
						<tr>
							<td colspan="5"  style="border: 0!important"><h3>Chi tiết hành khách</h3></td>
						</tr>
						<tr style="background-color: #009fe3;border: 1px solid #eee; height: 45px; color:white;">
							<th>Họ</th>
							<th>Tên</th>
							<th>Tuổi / Năm sinh</th>
							<th>Giới tính</th>
							<th>Loại</th>
						</tr>
						<?php $__currentLoopData = $ticket->passengers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $passenger): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($passenger->first_name); ?></td>
							<td><?php echo e($passenger->last_name); ?></td>
							<td><?php echo e($passenger->age); ?></td>
							<td><?php echo e($passenger->sex == 'M' ? 'Nam' : 'Nữ'); ?></td>
							<td><?php echo e($passenger->type == 'ADT' ? 'Người lớn' : ($passenger->type == 'CHD' ? 'trẻ em' : 'trẻ sơ sinh')); ?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</table>
					<table width="100%">
						<tr>
							<td colspan="5"  style="border: 0!important"><h3>Thông tin thanh toán</h3></td>
						</tr>
						<tr style="background-color: #009fe3;border: 1px solid #eee; height: 45px; color:white;">
							<th>Loại</th>
							<th width="10%">Số lượng</th>
							<th>Giá </th>
							<th>tổng Giá</th>
						</tr>
						<?php if($ticket->count_adult > 0): ?>
						<tr>
							<td>Giá vé Người lớn</td>
							<td><?php echo e($ticket->count_adult); ?></td>
							<td><?php echo e(number_format($ticket->price_adult)); ?> đ</td>
							<td><?php echo e(number_format($ticket->price_adult * $ticket->count_adult)); ?> đ</td>
						</tr>
						<?php endif; ?>
						<?php if($ticket->count_children > 0): ?>
						<tr>
							<td>Giá vé trẻ em</td>
							<td><?php echo e($ticket->count_children); ?></td>
							<td><?php echo e(number_format($ticket->price_children)); ?> đ</td>
							<td><?php echo e(number_format($ticket->price_children * $ticket->count_children)); ?> đ</td>
						</tr>
						<?php endif; ?>
						<?php if($ticket->count_baby > 0): ?>
						<tr>
							<td>Giá vé trẻ sơ sinh</td>
							<td><?php echo e($ticket->count_baby); ?></td>
							<td><?php echo e(number_format($ticket->price_baby)); ?> đ</td>
							<td><?php echo e(number_format($ticket->price_baby * $ticket->count_baby)); ?> đ</td>
						</tr>
						<?php endif; ?>
						<?php if($ticket->count_adult > 0): ?>
						<tr>
							<td>Giá dịch vụ Người lớn</td>
							<td><?php echo e($ticket->count_adult); ?></td>
							<td><?php echo e(number_format($ticket->service_adult)); ?> đ</td>
							<td><?php echo e(number_format($ticket->service_adult * $ticket->count_adult )); ?> đ</td>
						</tr>
						<?php endif; ?>
						<?php if($ticket->count_children > 0): ?>
						<tr>
							<td>Giá dịch vụ trẻ em</td>
							<td><?php echo e($ticket->count_children); ?></td>
							<td><?php echo e(number_format($ticket->service_children)); ?> đ</td>
							<td><?php echo e(number_format($ticket->service_children * $ticket->count_children)); ?> đ</td>
						</tr>
						<?php endif; ?>
						<?php if($ticket->count_baby > 0): ?>
						<tr>
							<td>Giá dịch vụ trẻ sơ sinh</td>
							<td><?php echo e($ticket->count_baby); ?></td>
							<td><?php echo e(number_format($ticket->service_baby)); ?> đ</td>
							<td><?php echo e(number_format($ticket->service_baby * $ticket->count_baby)); ?> đ</td>
						</tr>
						<?php endif; ?>
						<?php if($ticket->gift > 0): ?>
						<tr>
							<td colspan="2">Khuyến mãi</td>
							<td><?php echo e(number_format($ticket->gift)); ?> đ</td>
							<td><?php echo e(number_format($ticket->gift)); ?> đ</td>
						</tr>
						<?php endif; ?>

						<tr>
							<td colspan="3">Tổng giá</td>
							<td><strong><?php echo e(number_format($ticket->total)); ?> đ</strong></td>
						</tr>

					</table>
					<table width="100%">
						<tr>
							<td colspan="4"  style="border: 0!important"><h3>Chi tiết chuyến bay</h3></td>
						</tr>
						<tr style="background-color: #009fe3;border: 1px solid #eee; height: 45px; color:white;">
							<th>Mã đặt vé</th>
							<th>Điểm đến</th>
							<th>Điểm đi</th>
							<th>Khứ hồi / Một chiều</th>
						</tr>
						<tr>
							<td><?php echo e($ticket->seat_id); ?></td>
							<td><?php echo e($ticket->start_place); ?></td>
							<td><?php echo e($ticket->end_place); ?></td>
							<td><?php echo e($ticket->mode == 2 ? 'khứ hồi' : 'Một chiều'); ?></td>
						</tr>
					</table>

				</td>
			</tr>

        </table>
    </td>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('email.temple', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>