<div class="form" >
    <form action="/ticket" id="formid">
        <div class="text-center">

            <span class="radio radio-primary">
                <input type="radio" name="mode" id="radio2" value="one_way" <?php if($mode == 'one_way'): ?> checked="checked"  <?php endif; ?> onclick="modechange('one_way')">
                <label for="radio2" class="text-white">
                    Một chiều
                </label>
            </span> &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;
            <span class="radio radio-primary">
                <input type="radio" name="mode" id="radio1" value="two_way" <?php if($mode == 'two_way'): ?> checked="checked"  <?php endif; ?>  onclick="modechange('two_way')">
                <label for="radio1"  class="text-white">
                    Khứ hồi
                </label>
            </span>
        </div>
        <br>
        <div class="form-booking">
            <div class="select-place" >
                <div class="row">
                    <div class="col-md-6" >
                        <label>NƠI ĐI</label>
                        <input type="text" onclick="openPopover('popover-start')" id="start_place" name="start_place" placeholder="Điểm đi" required value="<?php echo e($start_place); ?>" readonly="" />
                        <div id="popover-start" class="dropdown-menu location-select">
                            <div class="popover-header text-left" style="background: #3097D1; height: 50px; padding: 15px 15px 0 15px" >

                                <h4 class="no-margin hidden-xs text-white" style="display: inline-block;">Chọn lựa điểm đi &nbsp;&nbsp;&nbsp;&nbsp;</h4>
                                <ul class="no-list no-padding text-white" style="display: inline-block;">
                                    <li class="active" ><a data-toggle="tab" href="#country" class="text-white">Nội địa</a></li>
                                    <li>&nbsp;&nbsp; || &nbsp;&nbsp; </li>
                                    <li ><a data-toggle="tab" href="#asia" class="text-white">Khu vực - Quốc tế</a></li>
                                </ul>
                            </div>
                            <div class="popover-body">
                                <div class="tab-content place-select" style="padding: 20px 30px;">
                                    <div id="country" class="tab-pane fade in active">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <h4>Miền Nam</h4>
                                                <ul>
                                                    <li ><a class="place" >Hồ Chí Minh (SGN)</a></li>
                                                    <li ><a class="place" >Cần Thơ (VCA)</a></li>
                                                    <li ><a class="place" >Kiên Giang (VKG)</a></li>
                                                    <li ><a class="place" >Cà Mau (CAH)</a></li>
                                                    <li ><a class="place" >Phú Quốc (PQC)</a></li>
                                                    <li ><a class="place" >Côn Đảo (VCS)</a></li>
                                                </ul>
                                            </div>
                                            <div class="col-sm-4">
                                                <h4>Miền Trung</h4>
                                                <ul>
                                                    <li ><a class="place" >Đà Nẵng (DAD)</a></li>
                                                    <li ><a class="place" >Quảng Bình (VDH)</a></li>
                                                    <li ><a class="place" >Quảng Nam (VCL)</a></li>
                                                    <li ><a class="place" >Huế (HUI)</a></li>
                                                    <li ><a class="place" >PleiKu (PXU)</a></li>
                                                    <li ><a class="place" >Phú Yên (TBB)</a></li>
                                                    <li ><a class="place" >Ban Mê Thuột (BMV)</a></li>
                                                    <li ><a class="place" >Nha Trang (CXR)</a></li>
                                                    <li ><a class="place" >Qui Nhơn (UIH)</a></li>
                                                    <li ><a class="place" >Đà Lạt (DLI)</a></li>
                                                </ul>
                                            </div>
                                            <div class="col-sm-4">
                                                <h4>Miền Bắc</h4>
                                                <ul>
                                                    <li ><a class="place" >Hà Nội (HAN)</a></li>
                                                    <li ><a class="place" >Điện Biên Phủ (DIN)</a></li>
                                                    <li ><a class="place" >Hải Phòng (HPH)</a></li>
                                                    <li ><a class="place" >Thanh Hóa (THD)</a></li>
                                                    <li ><a class="place" >Vinh (VII)</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="asia" class="tab-pane fade">
                                        <div class="row ">
                                            <div  class="col-sm-3">
                                                <h4>Đông Dương</h4>
                                                <ul>
                                                    <li><a class="place" >Phnôm Pênh (PNH)</a></li>
                                                    <li><a class="place" >Siem Reap (REP)</a></li>
                                                    <li><a class="place" >Viên Chăn (VTE)</a></li>
                                                    <li><a class="place" >Luông pra băng (LPQ)</a></li>
                                                </ul>
                                                <h4>Đông Nam Á</h4>
                                                <ul>
                                                    <li><a class="place" >Jakarta (JKT)</a></li>
                                                    <li><a class="place" >Băng Cốc (BKK)</a></li>
                                                    <li><a class="place" >Bali Denpasar (DPS)</a></li>
                                                    <li><a class="place" >Kuala Lumpur (KUL)</a></li>
                                                    <li><a class="place" >Manila (MNL)</a></li>
                                                    <li><a class="place" >Singapore (SIN)</a></li>
                                                    <li><a class="place" >Yangon (RGN)</a></li>
                                                </ul>
                                                <h4>Châu Phi</h4>
                                                <ul>
                                                    <li><a class="place" >Nairobi (NBO)</a></li>
                                                    <li><a class="place" >Maputo (MPM)</a></li>
                                                    <li><a class="place" >Luanda (LAD)</a></li>
                                                    <li><a class="place" >Johannesburg (JNB)</a></li>
                                                    <li><a class="place" >Cape Town (CPT)</a></li>
                                                    <li><a class="place" >Dar Es Salaam (DAR)</a></li>
                                                </ul>
                                            </div>
                                            <div   class="col-sm-3">
                                                <h4>Đông Bắc Á</h4>
                                                <ul>
                                                    <li><a class="place" >Bắc Kinh (BJS)</a></li>
                                                    <li><a class="place" >Thượng Hải (PVG)</a></li>
                                                    <li><a class="place" >Quảng Châu (CAN)</a></li>
                                                    <li><a class="place" >Hồng Kông (HKG)</a></li>
                                                    <li><a class="place" >Tokyo (NRT)</a></li>
                                                    <li><a class="place" >Tokyo (HND)</a></li>
                                                    <li><a class="place" >Nagoya (NGO)</a></li>
                                                    <li><a class="place" >Fukuoka (FUK)</a></li>
                                                    <li><a class="place" >Osaka (OSA)</a></li>
                                                    <li><a class="place" >Seoul (ICN)</a></li>
                                                    <li><a class="place" >Pusan (PUS)</a></li>
                                                </ul>
                                                <h4>Tây Á - Trung Đông</h4>
                                                <ul>

                                                    <li><a class="place" >Mumbai (BOM)</a></li>
                                                    <li><a class="place" >Đê-li (DEL)</a></li>
                                                    <li><a class="place" >Kathmandu (KTM)</a></li>
                                                    <li><a class="place" >Dhaka (DAC)</a></li>
                                                    <li><a class="place" >Colombo (CMB)</a></li>
                                                    <li><a class="place" >Kolkata (CCU)</a></li>
                                                    <li><a class="place" >Istanbul (IST)</a></li>
                                                    <li><a class="place" >Dubai (DXB)</a></li>
                                                </ul>
                                            </div>
                                            <div  class="col-sm-3">
                                                <h4>Châu Đại Dương</h4>
                                                <ul>
                                                    <li><a class="place" >Men-bơn (MEL)</a></li>
                                                    <li><a class="place" >Sydney (SYD)</a></li>
                                                    <li><a class="place" >Adelaide (ADL)</a></li>
                                                    <li><a class="place" >Brisbane (BNE)</a></li>
                                                    <li><a class="place" >Auckland (AKL)</a></li>
                                                    <li><a class="place" >Wellington (WLG)</a></li>

                                                </ul>
                                                <h4>Châu Âu</h4>
                                                <ul>

                                                    <li><a class="place" >Paris (CDG)</a></li>
                                                    <li><a class="place" >Luân Đôn (LON)</a></li>
                                                    <li><a class="place" >Manchester (MAN)</a></li>
                                                    <li><a class="place" >Berlin (TXL)</a></li>
                                                    <li><a class="place" >Frankfurt (FRA)</a></li>
                                                    <li><a class="place" >Amsterdam (AMS)</a></li>
                                                    <li><a class="place" >Madrid (MAD)</a></li>
                                                    <li><a class="place" >Mát-xờ-cơ-va (MOW)</a></li>
                                                    <li><a class="place" >Geneva (GVA)</a></li>
                                                    <li><a class="place" >Praha (PRG)</a></li>
                                                    <li><a class="place" >Rome (ROM)</a></li>
                                                    <li><a class="place" >Viên (VIE)</a></li>
                                                    <li><a class="place" >Cô-pen-ha-gen (CPH)</a></li>

                                                </ul>
                                            </div>
                                            <div  class="col-sm-3">
                                                <h4>Mỹ - Canada</h4>
                                                <ul>

                                                    <li><a class="place" >New York (NYC)</a></li>
                                                    <li><a class="place" >Washington (WAS)</a></li>
                                                    <li><a class="place" >New York (JFK)</a></li>
                                                    <li><a class="place" >Los Angeles (LAX)</a></li>
                                                    <li><a class="place" >San Francisco (SFO)</a></li>
                                                    <li><a class="place" >Atlanta (ATL)</a></li>
                                                    <li><a class="place" >Boston (BOS)</a></li>
                                                    <li><a class="place" >Chicago (CHI)</a></li>
                                                    <li><a class="place" >Dallas (DFW)</a></li>
                                                    <li><a class="place" >Denver (DEN)</a></li>
                                                    <li><a class="place" >Honolulu (HNL)</a></li>
                                                    <li><a class="place" >Miami (MIA)</a></li>
                                                    <li><a class="place" >Minneapolis (MSP)</a></li>
                                                    <li><a class="place" >Philadelphia (PHL)</a></li>
                                                    <li><a class="place" >Portland (Oregon) (PDX)</a></li>
                                                    <li><a class="place" >Seattle (SEA)</a></li>
                                                    <li><a class="place" >St Louis (STL)</a></li>
                                                    <li><a class="place" >Vancouver (YVR)</a></li>
                                                    <li><a class="place" >Toronto (YYZ)</a></li>
                                                    <li><a class="place" >Ottawa (YOW)</a></li>
                                                    <li><a class="place" >Montreal (YMQ)</a></li>

                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6" >
                        <label>NƠI ĐẾN</label>
                        <input type="text" onclick="openPopover('popover-end')" id="end_place" name="end_place"  placeholder="Điểm đến" required  value="<?php echo e($end_place); ?>"  readonly=""  />
                        <div id="popover-end" class="dropdown-menu location-select" style="padding: 0">
                            <div class="popover-header text-left" style="background: #3097D1; height: 50px; padding: 15px 15px 0 15px" >

                                <h4 class="no-margin hidden-xs text-white" style="display: inline-block;">Chọn lựa điểm đến &nbsp;&nbsp;&nbsp;&nbsp;</h4>
                                <ul class="no-list no-padding text-white" style="display: inline-block;">
                                    <li  ><a data-toggle="tab" href="#country2" class="text-white">Nội địa</a></li>
                                    <li>&nbsp;&nbsp; || &nbsp;&nbsp; </li>
                                    <li  class="active"><a data-toggle="tab" href="#asia2" class="text-white">Khu vực - Quốc tế</a></li>
                                </ul>
                            </div>
                            <div class="popover-body">
                                <div class="tab-content place-select" style="padding: 20px 30px;">
                                    <div id="country2" class="tab-pane fade">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <h4>Miền Nam</h4>
                                                <ul>
                                                    <li ><a class="place" >Hồ Chí Minh (SGN)</a></li>
                                                    <li ><a class="place" >Cần Thơ (VCA)</a></li>
                                                    <li ><a class="place" >Kiên Giang (VKG)</a></li>
                                                    <li ><a class="place" >Cà Mau (CAH)</a></li>
                                                    <li ><a class="place" >Phú Quốc (PQC)</a></li>
                                                    <li ><a class="place" >Côn Đảo (VCS)</a></li>
                                                </ul>
                                            </div>
                                            <div class="col-sm-4">
                                                <h4>Miền Trung</h4>
                                                <ul>
                                                    <li ><a class="place" >Đà Nẵng (DAD)</a></li>
                                                    <li ><a class="place" >Quảng Bình (VDH)</a></li>
                                                    <li ><a class="place" >Quảng Nam (VCL)</a></li>
                                                    <li ><a class="place" >Huế (HUI)</a></li>
                                                    <li ><a class="place" >PleiKu (PXU)</a></li>
                                                    <li ><a class="place" >Phú Yên (TBB)</a></li>
                                                    <li ><a class="place" >Ban Mê Thuột (BMV)</a></li>
                                                    <li ><a class="place" >Nha Trang (CXR)</a></li>
                                                    <li ><a class="place" >Qui Nhơn (UIH)</a></li>
                                                    <li ><a class="place" >Đà Lạt (DLI)</a></li>
                                                </ul>
                                            </div>
                                            <div class="col-sm-4">
                                                <h4>Miền Bắc</h4>
                                                <ul>
                                                    <li ><a class="place" >Hà Nội (HAN)</a></li>
                                                    <li ><a class="place" >Điện Biên Phủ (DIN)</a></li>
                                                    <li ><a class="place" >Hải Phòng (HPH)</a></li>
                                                    <li ><a class="place" >Thanh Hóa (THD)</a></li>
                                                    <li ><a class="place" >Vinh (VII)</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="asia2" class="tab-pane fade in active">
                                        <div class="row ">
                                            <div  class="col-sm-3">
                                                <h4>Đông Dương</h4>
                                                <ul>
                                                    <li><a class="place" >Phnôm Pênh (PNH)</a></li>
                                                    <li><a class="place" >Siem Reap (REP)</a></li>
                                                    <li><a class="place" >Viên Chăn (VTE)</a></li>
                                                    <li><a class="place" >Luông pra băng (LPQ)</a></li>
                                                </ul>
                                                <h4>Đông Nam Á</h4>
                                                <ul>
                                                    <li><a class="place" >Jakarta (JKT)</a></li>
                                                    <li><a class="place" >Băng Cốc (BKK)</a></li>
                                                    <li><a class="place" >Bali Denpasar (DPS)</a></li>
                                                    <li><a class="place" >Kuala Lumpur (KUL)</a></li>
                                                    <li><a class="place" >Manila (MNL)</a></li>
                                                    <li><a class="place" >Singapore (SIN)</a></li>
                                                    <li><a class="place" >Yangon (RGN)</a></li>
                                                </ul>
                                                <h4>Châu Phi</h4>
                                                <ul>
                                                    <li><a class="place" >Nairobi (NBO)</a></li>
                                                    <li><a class="place" >Maputo (MPM)</a></li>
                                                    <li><a class="place" >Luanda (LAD)</a></li>
                                                    <li><a class="place" >Johannesburg (JNB)</a></li>
                                                    <li><a class="place" >Cape Town (CPT)</a></li>
                                                    <li><a class="place" >Dar Es Salaam (DAR)</a></li>
                                                </ul>
                                            </div>
                                            <div   class="col-sm-3">
                                                <h4>Đông Bắc Á</h4>
                                                <ul>
                                                    <li><a class="place" >Bắc Kinh (BJS)</a></li>
                                                    <li><a class="place" >Thượng Hải (PVG)</a></li>
                                                    <li><a class="place" >Quảng Châu (CAN)</a></li>
                                                    <li><a class="place" >Hồng Kông (HKG)</a></li>
                                                    <li><a class="place" >Tokyo (NRT)</a></li>
                                                    <li><a class="place" >Tokyo (HND)</a></li>
                                                    <li><a class="place" >Nagoya (NGO)</a></li>
                                                    <li><a class="place" >Fukuoka (FUK)</a></li>
                                                    <li><a class="place" >Osaka (OSA)</a></li>
                                                    <li><a class="place" >Seoul (ICN)</a></li>
                                                    <li><a class="place" >Pusan (PUS)</a></li>
                                                </ul>
                                                <h4>Tây Á - Trung Đông</h4>
                                                <ul>

                                                    <li><a class="place" >Mumbai (BOM)</a></li>
                                                    <li><a class="place" >Đê-li (DEL)</a></li>
                                                    <li><a class="place" >Kathmandu (KTM)</a></li>
                                                    <li><a class="place" >Dhaka (DAC)</a></li>
                                                    <li><a class="place" >Colombo (CMB)</a></li>
                                                    <li><a class="place" >Kolkata (CCU)</a></li>
                                                    <li><a class="place" >Istanbul (IST)</a></li>
                                                    <li><a class="place" >Dubai (DXB)</a></li>
                                                </ul>
                                            </div>
                                            <div  class="col-sm-3">
                                                <h4>Châu Đại Dương</h4>
                                                <ul>
                                                    <li><a class="place" >Men-bơn (MEL)</a></li>
                                                    <li><a class="place" >Sydney (SYD)</a></li>
                                                    <li><a class="place" >Adelaide (ADL)</a></li>
                                                    <li><a class="place" >Brisbane (BNE)</a></li>
                                                    <li><a class="place" >Auckland (AKL)</a></li>
                                                    <li><a class="place" >Wellington (WLG)</a></li>

                                                </ul>
                                                <h4>Châu Âu</h4>
                                                <ul>

                                                    <li><a class="place" >Paris (CDG)</a></li>
                                                    <li><a class="place" >Luân Đôn (LON)</a></li>
                                                    <li><a class="place" >Manchester (MAN)</a></li>
                                                    <li><a class="place" >Berlin (TXL)</a></li>
                                                    <li><a class="place" >Frankfurt (FRA)</a></li>
                                                    <li><a class="place" >Amsterdam (AMS)</a></li>
                                                    <li><a class="place" >Madrid (MAD)</a></li>
                                                    <li><a class="place" >Mát-xờ-cơ-va (MOW)</a></li>
                                                    <li><a class="place" >Geneva (GVA)</a></li>
                                                    <li><a class="place" >Praha (PRG)</a></li>
                                                    <li><a class="place" >Rome (ROM)</a></li>
                                                    <li><a class="place" >Viên (VIE)</a></li>
                                                    <li><a class="place" >Cô-pen-ha-gen (CPH)</a></li>

                                                </ul>
                                            </div>
                                            <div  class="col-sm-3">
                                                <h4>Mỹ - Canada</h4>
                                                <ul>

                                                    <li><a class="place" >New York (NYC)</a></li>
                                                    <li><a class="place" >Washington (WAS)</a></li>
                                                    <li><a class="place" >New York (JFK)</a></li>
                                                    <li><a class="place" >Los Angeles (LAX)</a></li>
                                                    <li><a class="place" >San Francisco (SFO)</a></li>
                                                    <li><a class="place" >Atlanta (ATL)</a></li>
                                                    <li><a class="place" >Boston (BOS)</a></li>
                                                    <li><a class="place" >Chicago (CHI)</a></li>
                                                    <li><a class="place" >Dallas (DFW)</a></li>
                                                    <li><a class="place" >Denver (DEN)</a></li>
                                                    <li><a class="place" >Honolulu (HNL)</a></li>
                                                    <li><a class="place" >Miami (MIA)</a></li>
                                                    <li><a class="place" >Minneapolis (MSP)</a></li>
                                                    <li><a class="place" >Philadelphia (PHL)</a></li>
                                                    <li><a class="place" >Portland (Oregon) (PDX)</a></li>
                                                    <li><a class="place" >Seattle (SEA)</a></li>
                                                    <li><a class="place" >St Louis (STL)</a></li>
                                                    <li><a class="place" >Vancouver (YVR)</a></li>
                                                    <li><a class="place" >Toronto (YYZ)</a></li>
                                                    <li><a class="place" >Ottawa (YOW)</a></li>
                                                    <li><a class="place" >Montreal (YMQ)</a></li>

                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="select-date">
                <div class="row">
                    <div class="col-md-6">
                        <i class="fa fa-calendar input-icon"></i>
                        <input type="text" id="start_date"  onchange="change_start()" placeholder="Ngày đi" required name="start_date" readonly="" value="<?php echo e($start_date); ?>">
                    </div>

                    <div class="col-md-6" id="end_date_section">
                        <i class="fa fa-calendar input-icon"></i>
                        <input type="text" placeholder="Ngày về" id="end_date" onchange="update_mode()" required name="end_date" readonly="" value="<?php echo e($end_date); ?>">
                    </div>
                </div>
            </div>
            <div class="number">
                <div class="row">
                    <div class="col-md-4"> 
                        <i class="fa fa-user input-icon"></i>
                        <p class="des">Người lớn</p>
                        <select name="adult" required="" value="<?php echo e($adult); ?>">
                            <option <?php if($adult == '1'): ?> selected <?php endif; ?> >1</option>
                            <option <?php if($adult == '2'): ?> selected <?php endif; ?> >2</option>
                            <option <?php if($adult == '3'): ?> selected <?php endif; ?> >3</option>
                            <option <?php if($adult == '4'): ?> selected <?php endif; ?> >4</option>
                            <option <?php if($adult == '5'): ?> selected <?php endif; ?> >5</option>
                            <option <?php if($adult == '6'): ?> selected <?php endif; ?> >6</option>
                            <option <?php if($adult == '7'): ?> selected <?php endif; ?> >7</option>
                            <option <?php if($adult == '8'): ?> selected <?php endif; ?> >8</option>
                            <option <?php if($adult == '9'): ?> selected <?php endif; ?> >9</option>
                        </select>
                        <p>Từ 12 tuổi trở lên</p>
                    </div>
                    <div class="col-md-4"> 
                        <p class="des">Trẻ em</p>
                        <i class="fa fa-child input-icon"></i>
                        <select name="children" required="">
                            <option <?php if($children == '0'): ?> selected <?php endif; ?> >0</option>
                            <option <?php if($children == '1'): ?> selected <?php endif; ?> >1</option>
                            <option <?php if($children == '2'): ?> selected <?php endif; ?> >2</option>
                            <option <?php if($children == '3'): ?> selected <?php endif; ?> >3</option>
                            <option <?php if($children == '4'): ?> selected <?php endif; ?> >4</option>
                            <option <?php if($children == '5'): ?> selected <?php endif; ?> >5</option>
                            <option <?php if($children == '6'): ?> selected <?php endif; ?> >6</option>
                            <option <?php if($children == '7'): ?> selected <?php endif; ?> >7</option>
                            <option <?php if($children == '8'): ?> selected <?php endif; ?> >8</option>
                            <option <?php if($children == '9'): ?> selected <?php endif; ?> >9</option>
                        </select>
                        <p>Từ 2 - 11 tuổi</p>
                    </div>
                    <div class="col-md-4"> 
                        <p class="des">Trẻ sơ sinh</p>
                        <i class="fa fa-user input-icon"></i>
                        <select name="baby" required="">
                            <option <?php if($baby == '0'): ?> selected <?php endif; ?> >0</option>
                            <option <?php if($baby == '1'): ?> selected <?php endif; ?> >1</option>
                            <option <?php if($baby == '2'): ?> selected <?php endif; ?> >2</option>
                            <option <?php if($baby == '3'): ?> selected <?php endif; ?> >3</option>
                            <option <?php if($baby == '4'): ?> selected <?php endif; ?> >4</option>
                            <option <?php if($baby == '5'): ?> selected <?php endif; ?> >5</option>
                            <option <?php if($baby == '6'): ?> selected <?php endif; ?> >6</option>
                            <option <?php if($baby == '7'): ?> selected <?php endif; ?> >7</option>
                            <option <?php if($baby == '8'): ?> selected <?php endif; ?> >8</option>
                            <option <?php if($baby == '9'): ?> selected <?php endif; ?> >9</option>
                        </select>
                        <p>Dưới 24 tháng tuổi</p>
                    </div>
                </div>
            </div>

            <div style="clear: both;"></div>

            <div class="text-center">
                <button class="submit"  type="submit"><i class="fa fa-search"></i> &nbsp;&nbsp; Tìm chuyến bay</button>
            </div>
        </div>

    </form>
</div>
<script type="text/javascript">
    var adult = 1;
    var children = 0;
    var baby = 0;
    function down(type){
        if(type == 'adult'){
            if(adult > 0)
                adult = adult - 1;
        }else if(type == 'children'){
            if(children > 0)
                children = children - 1;
        }else if(type == 'baby'){
            if(baby > 0)
                baby = baby - 1;
        }
        update();
    }
    function up(type){
        if(type == 'adult'){
            if(adult < 99)
                adult = adult + 1;
        }else if(type == 'children'){
            if(children < 99)
                children = children + 1;
        }else if(type == 'baby'){
            if(baby < 99)
                baby = baby + 1;
        }
        update();
    }
    function update(){
        $('#adult').html(adult);
        $('#adult-value').val(adult);
        $('#children').html(children);
        $('#children-value').val(children);
        $('#baby').html(baby);
        $('#baby-value').val(baby);
        var total = adult + children + baby;
        $('#number-passenger').val(total + ' hành khách');
    }
    function openPopover(id){
        $('#'+id).fadeIn(50);
    }
    function closePopover(id){
        $('#'+id).hide();
    }
    function change_place(){
        var tmp = $('#start_place').val();
        $('#start_place').val($('#end_place').val());
        $('#end_place').val(tmp);
    }
    modechange('<?php echo e($mode); ?>');
    function modechange(type){
        if(type == 'one_way'){
            $('#end_date').val('');
            $('#end_date_section').css('display', 'none');
        }
        if(type == 'two_way'){
            $('#end_date_section').css('display', 'block');
            $('#end_date').val($('#start_date').val());
        }
    }
    function update_mode(){
        $('#radio1').prop('checked',true);
    }
    $(document).mouseup(function(e){
        var passenger_div = $("#popover-passenger");
        if (!passenger_div.is(e.target) && passenger_div.has(e.target).length === 0){
            passenger_div.hide();
        }

        var start_div = $("#popover-start");
        if (!start_div.is(e.target) && start_div.has(e.target).length === 0){
            start_div.hide();
        }
        var end_div = $("#popover-end");
        if (!end_div.is(e.target) && end_div.has(e.target).length === 0){
            end_div.hide();
        }
        var first_search = $("#result-search-first");
        if (!first_search.is(e.target) && first_search.has(e.target).length === 0){
            first_search.hide();
        }
        var back_search = $("#result-search-back");
        if (!back_search.is(e.target) && back_search.has(e.target).length === 0){
            back_search.hide();
        }
    });

    $('#popover-start .place').click(function(event){
        console.log(event);
        var data = $(this).html();

        $('#start_place').val(data);
        $("#popover-start").hide();
    })
    $('#popover-end .place').click(function(event){
        console.log(event);
        var data = $(this).html();

        $('#end_place').val(data);
        $("#popover-end").hide();
    })
    $( function() {
        var dateToday = new Date();
        var tomorrow = new Date(dateToday.getTime() + (24 * 60 * 60 * 1000));
        $( "#start_date" ).datepicker({ numberOfMonths: 1 , minDate: dateToday, dateFormat: 'dd/mm/yy'});
        $( "#end_date" ).datepicker({ numberOfMonths: 1, minDate: dateToday , dateFormat: 'dd/mm/yy'});
        $( "#start_date" ).val('<?php echo e($start_date); ?>');
        $( "#end_date" ).val('<?php echo e($end_date); ?>');

    })
    function change_start(){
        if($( "#end_date" ).val() == ''){
            $( "#end_date" ).val($('#start_date').val());
        }
    }
    var airports = [];
    $.get("/search_point", function(data){
        airports = JSON.parse(data);

    })

    function search_airport(type){


        var s = $('#'+type).val();
        if(s && s.length > 2){
            $('#result-search-'+type).css('display', 'initial');
            $('#result-search-'+type).html('<ul></ul>');
            $.get("/search_point?limit=5&key="+s, function(data){
                var data = JSON.parse(data);

                if(data){
                    $.map(data, function(value, index){
                        var html = '<li><a class="place">'+value+'</a></li>';
                        $('#result-search-'+type+' ul').append(html);
                        console.log(html);
                    }) 
                }else{
                    var html = '<p class="text-center">Không có kết quả tìm kiếm</p>';
                    $('#result-search-'+type+' ul').append(html);
                }
                $('#popover-start .place').click(function(event){
                    console.log(event);
                    var data = $(this).html();

                    $('#start_place').val(data);
                    $("#popover-start").hide();

                });
                $('#popover-end .place').click(function(event){
                    console.log(event);
                    var data = $(this).html();

                    $('#end_place').val(data);
                    $("#popover-end").hide();
                })

            })
        }else{
            $('#result-search-'+type).css('display', 'none');
        }
    }
    $('#formid').on('keyup keypress', function(e) {
        var keyCode = e.keyCode || e.which;
        if (keyCode === 13) { 
            e.preventDefault();
            return false;
        }
    });


</script>