<?php $__env->startSection('content'); ?>

<style type="text/css">
    input[type = text],
    input[type = email],
    input[type = password],
    select {
        height: 50px;
        border: 1px solid #ccc;
        border-radius: 3px;

    }
    label{
        margin-top: 15px;
    }
</style>
<div class="container-fluid agency-bg" style="background-image: url(/img/bg-6.jpg); height: 250px; padding-top: 120px; background-position: cover">
    <div class="container">
        <h2 class="text-white">Trở thành đại lý cấp 2 của cty vé máy bay Trần Phong</h2>
        <a class="text-white" style="text-decoration-line: 1px" href="/agency">Lợi ích mang lại </a>

    </div>
</div>
<div class="container">
    <div class="row">
        <br>
        <div class="col-md-6"> 
            <h4>Những lợi ích mang lại khi trở thành đại lý cấp 2</h4>
            <br>
            <br>
            <p ><strong>Lorem Ipsum is simply dummy text </strong></p>
            <p>The printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
            <br>
            <p ><strong>Lorem Ipsum is simply dummy text </strong></p>
            <p>The printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
            <br>
            <p ><strong>Lorem Ipsum is simply dummy text </strong></p>
            <p>The printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
            
        </div>
        <div class="col-md-6">
            <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/agency/save')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="row">
                    <div class="col-md-3 text-right">
                        <label>Họ và tên đệm</label>
                    </div>
                    <div class="col-md-9">
                        <input id="name" type="text" class="form-control" name="first_name" required autofocus>
                    </div>
                </div>
                <br>
                <div class="row">
                    <div class="col-md-3 text-right">
                        <label>Tên</label>
                    </div>
                    <div class="col-md-9">
                        <input id="name" type="text" class="form-control" name="last_name" required >
                    </div>
                </div>
                <br>
                <div class="row">
                    <div class="col-md-3 text-right">
                        <label >Địa chỉ email</label>
                    </div>

                    <div class="col-md-9">
                        <input id="name" type="email" class="form-control" name="first_name" required>
                    </div>
                </div>
                <br>
                <div class="row">
                    <div class="col-md-3 text-right">
                        <label >Số điện thoại</label>
                    </div>

                    <div class="col-md-9">
                        <input id="name" type="email" class="form-control" name="first_name" required>
                    </div>
                </div>
                <br> 
                <div class="row">
                    <div class="col-md-3 text-right">
                        <label >Địa chỉ</label>
                    </div>

                    <div class="col-md-9">
                        <input id="name" type="email" class="form-control" name="first_name" required>
                    </div>

                </div>
                <br>
                <div class="row">
                    <div class="col-md-6 col-md-offset-6">
                        <button type="submit" class="btn btn-primary" style="height: 50px; border-radius: 3px; width: 100%">
                            Đăng ký
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<br>
<br>
<br>
<?php $__env->startComponent('component.footer'); ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>