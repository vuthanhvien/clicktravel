<?php $__env->startSection('content'); ?>

<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
										<div class="row">
						<div class="col-xs-5"><h4 class="title">Thông tin khách hàng</h4>
						</div>
						<div class="col-xs-7 text-right">
							<span>
								<ul class="pagination pull-right" style="margin:0; color: #555">
									<?php if( $contacts->currentPage() != 1): ?> 
										<li><a href="/admin/contact?s=<?php echo e($search); ?>&page=1">Trang đầu</a></li>
									<?php else: ?>
										<li class="disabled"><a href="/admin/contact?s=<?php echo e($search); ?>&page=1">Trang đầu</a></li>

									<?php endif; ?>
									<?php if( $contacts->currentPage() == $contacts->lastPage()  && $contacts->currentPage() > 4): ?>
										<li><a href="/admin/contact?s=<?php echo e($search); ?>&page=<?php echo e($contacts->currentPage() - 4); ?>"><?php echo e($contacts->currentPage() - 4); ?></a></li>
									<?php endif; ?>
									<?php if(( $contacts->currentPage() == $contacts->lastPage() - 1 ||  $contacts->currentPage() == $contacts->lastPage()) &&   $contacts->currentPage() > 3): ?> 
										<li><a href="/admin/contact?s=<?php echo e($search); ?>&page=<?php echo e($contacts->currentPage() - 3); ?>"><?php echo e($contacts->currentPage() - 3); ?></a></li>
									<?php endif; ?>
									<?php if( $contacts->currentPage() > 2): ?> 
										<li><a href="/admin/contact?s=<?php echo e($search); ?>&page=<?php echo e($contacts->currentPage() - 2); ?>"><?php echo e($contacts->currentPage() - 2); ?></a></li>
									<?php endif; ?>
									<?php if( $contacts->currentPage() > 1): ?> 
										<li><a href="/admin/contact?s=<?php echo e($search); ?>&page=<?php echo e($contacts->currentPage() - 1); ?>"><?php echo e($contacts->currentPage() - 1); ?></a></li>
									<?php endif; ?>

									<li  class="active"><a  href="#"><?php echo e($contacts->currentPage()); ?></a></li>

									<?php if( $contacts->currentPage() < $contacts->lastPage()): ?> 
										<li><a href="/admin/contact?s=<?php echo e($search); ?>&page=<?php echo e($contacts->currentPage() + 1); ?>"><?php echo e($contacts->currentPage() + 1); ?></a></li>
									<?php endif; ?>
									<?php if( $contacts->currentPage() < $contacts->lastPage() - 1 ): ?> 
										<li><a href="/admin/contact?s=<?php echo e($search); ?>&page=<?php echo e($contacts->currentPage() + 2); ?>"><?php echo e($contacts->currentPage() + 2); ?></a></li>
									<?php endif; ?>
									<?php if(( $contacts->currentPage() == 2 ||  $contacts->currentPage() == 1) && $contacts->lastPage() > 3 ): ?>
										<li><a href="/admin/contact?s=<?php echo e($search); ?>&page=<?php echo e($contacts->currentPage() + 3); ?>"><?php echo e($contacts->currentPage() + 3); ?></a></li>
									<?php endif; ?>
									<?php if( $contacts->currentPage() == 1 && $contacts->lastPage() > 4): ?> 
										<li><a href="/admin/contact?s=<?php echo e($search); ?>&page=<?php echo e($contacts->currentPage() + 4); ?>"><?php echo e($contacts->currentPage() + 4); ?></a></li>
									<?php endif; ?>
									<?php if( $contacts->currentPage() != $contacts->lastPage() ): ?> 
										<li><a href="/admin/contact?s=<?php echo e($search); ?>&page=<?php echo e($contacts->lastPage()); ?>">Trang cuối</a></li>
									<?php else: ?>
										<li class="disabled"><a href="/admin/contact?s=<?php echo e($search); ?>&page=<?php echo e($contacts->lastPage()); ?>">Trang cuối</a></li>
									<?php endif; ?>
								</ul>
								<style type="text/css">
									.pagination a{
										color: #555;
									}
									.card [data-background-color] a{
										color: initial;
									}
									.pagination li.active a{
										color: white;
									}
									.pagination li.disabled a{
										pointer-events: none;
									}
									.pagination li.disabled a{
										color: #ccc;
									}
								</style>
							</span>
							<form action="/admin/contact">
								<div class="pull-right" style="position: relative;" >
									<input placeholder="Tìm kiếm" name="s" value="<?php echo e($search); ?>" style="color:#555; padding-left: 15px;   height: 34px;border: 0;border-radius: 5px;margin-right: 17px;" onkeydown="if (event.keyCode == 13) { this.form.submit(); return false; }">
									<i style="position: absolute;color: #555;right: 25px;top: 10px;" class="fa fa-search"></i>
								</div>
							</form>
						</div>
					</div>
				</div>
				<div class="card-content table-responsive">
					<table class="table">
						<thead class="text-primary">
							<th>Tên</th>
							<th>Email</th>
							<th>Mã đặt chỗ</th>
							<th>Thao tác</th>
							<th>Ngày tạo</th>
						</thead>
						<tbody>
						<?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><strong><?php echo e($contact->name); ?></strong></td>
								<td><?php echo e($contact->email); ?></td>
								<td><?php echo e($contact->seat_id); ?></td>
								<td><a href="/admin/contact/<?php echo e($contact->id); ?>"> Chi tiết</a></td>
								<td><?php echo e($contact->created_at); ?></td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>

				</div>
			</div>
		</div>

		
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>