<?php $__env->startSection('content'); ?>

<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
							<div class="row">
						<div class="col-xs-5"><h4 class="title">Thông tin vé</h4>
						</div>
						<div class="col-xs-7 text-right">
							<span>
								<ul class="pagination pull-right" style="margin:0; color: #555">
									<?php if( $tickets->currentPage() != 1): ?> 
										<li><a href="/admin/ticket?s=<?php echo e($search); ?>&page=1">Trang đầu</a></li>
									<?php else: ?>
										<li class="disabled"><a href="/admin/ticket?s=<?php echo e($search); ?>&page=1">Trang đầu</a></li>

									<?php endif; ?>
									<?php if( $tickets->currentPage() == $tickets->lastPage()  && $tickets->currentPage() > 4): ?>
										<li><a href="/admin/ticket?s=<?php echo e($search); ?>&page=<?php echo e($tickets->currentPage() - 4); ?>"><?php echo e($tickets->currentPage() - 4); ?></a></li>
									<?php endif; ?>
									<?php if(( $tickets->currentPage() == $tickets->lastPage() - 1 ||  $tickets->currentPage() == $tickets->lastPage()) &&   $tickets->currentPage() > 3): ?> 
										<li><a href="/admin/ticket?s=<?php echo e($search); ?>&page=<?php echo e($tickets->currentPage() - 3); ?>"><?php echo e($tickets->currentPage() - 3); ?></a></li>
									<?php endif; ?>
									<?php if( $tickets->currentPage() > 2): ?> 
										<li><a href="/admin/ticket?s=<?php echo e($search); ?>&page=<?php echo e($tickets->currentPage() - 2); ?>"><?php echo e($tickets->currentPage() - 2); ?></a></li>
									<?php endif; ?>
									<?php if( $tickets->currentPage() > 1): ?> 
										<li><a href="/admin/ticket?s=<?php echo e($search); ?>&page=<?php echo e($tickets->currentPage() - 1); ?>"><?php echo e($tickets->currentPage() - 1); ?></a></li>
									<?php endif; ?>

									<li  class="active"><a  href="#"><?php echo e($tickets->currentPage()); ?></a></li>

									<?php if( $tickets->currentPage() < $tickets->lastPage()): ?> 
										<li><a href="/admin/ticket?s=<?php echo e($search); ?>&page=<?php echo e($tickets->currentPage() + 1); ?>"><?php echo e($tickets->currentPage() + 1); ?></a></li>
									<?php endif; ?>
									<?php if( $tickets->currentPage() < $tickets->lastPage() - 1 ): ?> 
										<li><a href="/admin/ticket?s=<?php echo e($search); ?>&page=<?php echo e($tickets->currentPage() + 2); ?>"><?php echo e($tickets->currentPage() + 2); ?></a></li>
									<?php endif; ?>
									<?php if(( $tickets->currentPage() == 2 ||  $tickets->currentPage() == 1) && $tickets->lastPage() > 3 ): ?>
										<li><a href="/admin/ticket?s=<?php echo e($search); ?>&page=<?php echo e($tickets->currentPage() + 3); ?>"><?php echo e($tickets->currentPage() + 3); ?></a></li>
									<?php endif; ?>
									<?php if( $tickets->currentPage() == 1 && $tickets->lastPage() > 4): ?> 
										<li><a href="/admin/ticket?s=<?php echo e($search); ?>&page=<?php echo e($tickets->currentPage() + 4); ?>"><?php echo e($tickets->currentPage() + 4); ?></a></li>
									<?php endif; ?>
									<?php if( $tickets->currentPage() != $tickets->lastPage() ): ?> 
										<li><a href="/admin/ticket?s=<?php echo e($search); ?>&page=<?php echo e($tickets->lastPage()); ?>">Trang cuối</a></li>
									<?php else: ?>
										<li class="disabled"><a href="/admin/ticket?s=<?php echo e($search); ?>&page=<?php echo e($tickets->lastPage()); ?>">Trang cuối</a></li>
									<?php endif; ?>
								</ul>
								<style type="text/css">
									.pagination a{
										color: #555;
									}
									.card [data-background-color] a{
										color: initial;
									}
									.pagination li.active a{
										color: white;
									}
									.pagination li.disabled a{
										pointer-events: none;
									}
									.pagination li.disabled a{
										color: #ccc;
									}
								</style>
							</span>
							<form action="/admin/ticket">
								<div class="pull-right" style="position: relative;" >
									<input placeholder="Tìm kiếm" name="s" value="<?php echo e($search); ?>" style="color:#555; padding-left: 15px;   height: 34px;border: 0;border-radius: 5px;margin-right: 17px;" onkeydown="if (event.keyCode == 13) { this.form.submit(); return false; }">
									<i style="position: absolute;color: #555;right: 25px;top: 10px;" class="fa fa-search"></i>
								</div>
							</form>
						</div>
					</div>
				</div>
				<div class="card-content table-responsive">
					<table class="table">
						<thead class="text-primary">
							<th>Liên hệ</th>
							<th>Mã ghế ngồi</th>
							<th>Số lượng</th>
							<th>Khứ hồi / Một chiều</th>
							<th>Giá net</th>
							<th>Giá dịch vụ</th>
							<th>Tổng giá (Cả khuyến mãi) </th>
							<th>Trạng thái</th>
							<th>Ngày tạo</th>
							<th>Người đặt</th>
							<th>Thao tác</th>
						</thead>
						<tbody>
						<?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($ticket->contact_name); ?></td>
								<td><?php echo e($ticket->seat_id); ?></td>
								<td><?php echo e($ticket->count_adult + $ticket->count_children + $ticket->count_baby); ?> hành khách</td>
								<td><?php if($ticket->mode == '1'): ?> Một chiều <?php else: ?> Khứ hồi <?php endif; ?> </td>
								<td class="money"><?php echo e($ticket->price_adult * $ticket->count_adult + $ticket->price_children * $ticket->count_children + $ticket->price_baby * $ticket->count_baby); ?> đ</td>
								<td class="money"><?php echo e($ticket->service_adult * $ticket->count_adult + $ticket->service_children * $ticket->count_children + $ticket->service_baby * $ticket->count_baby); ?> đ</td>
								<td class="money"><?php echo e($ticket->total); ?> đ</td>
								<td><?php echo e($status[$ticket->status]); ?></td>
								<td><?php echo e($ticket->created_at); ?></td>
								<td>
								<?php if( $ticket->user_id): ?>
								<a href="/admin/user/<?php echo e($ticket->user_id); ?>"><?php echo e($ticket->username); ?> (<?php if($ticket->role == '1'): ?> Quản trị <?php elseif($ticket->role == '2'): ?> Đại lý cấp 2 <?php elseif($ticket->role == '3'): ?> Nhân viên <?php elseif($ticket->role == '4'): ?> Khách hàng <?php endif; ?>)</a>
								<?php endif; ?>
								</td>
								<td class="text-primary"><a href="/admin/ticket/<?php echo e($ticket->id); ?>">Chi tiết	</a></td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
			<a href="/ticket" class="btn btn-success"><i class="fa fa-plus"></i> &nbsp;&nbsp;&nbsp; Đăng ký vé mới </a>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>