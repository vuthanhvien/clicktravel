<?php $__env->startSection('title'); ?>
Đăng ký đại lý cấp 2 <?php echo e($first_name); ?> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <td align="center" valign="top" width="100%" style="background-color: #ffffff;  border-top: 1px solid #e5e5e5; border-bottom: 1px solid #e5e5e5;">
      <center>
        <table cellpadding="0" cellspacing="0" width="600" class="w320">
            <tr>
              <td class="item-table">
                <table cellspacing="0" cellpadding="0" width="100%">
                  <tr>
                    <td class="title-dark" width="200">
                       Tên
                    </td>
                    <td class="title-dark" width="400">
						<?php echo e($first_name); ?>

                    </td>
                  </tr>
                  <tr>
                    <td class="title-dark" width="200">
                       Họ và tên đệm
                    </td>
                    <td class="title-dark" width="400">
						<?php echo e($last_name); ?>

                    </td>
                  </tr>
                  <tr>
                    <td class="title-dark" width="200">
                       Email
                    </td>
                    <td class="title-dark" width="400">
						<?php echo e($email); ?>

                    </td>
                  </tr>
                  <tr>
                    <td class="title-dark" width="200">
                       Điện thoại
                    </td>
                    <td class="title-dark" width="400">
						<?php echo e($phone); ?>

                    </td>
                  </tr>
                  <tr>
                    <td class="title-dark" width="200">
                       Địa chỉ
                    </td>
                    <td class="title-dark" width="400">
						<?php echo e($address); ?>

                    </td>
                  </tr>
                   <tr>
                    <td colspan="2" class="title-dark" width="200">
                       Nội dung
                    </td>
                  </tr>
                  <tr>
                    <td colspan="2" class="title-dark" width="200">
                       <?php echo e($memo); ?>

                    </td>
                  </tr>

                  



                </table>
              </td>
            </tr>

        </table>
      </center>
    </td>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('email.temple', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>