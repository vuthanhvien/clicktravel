<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row">
		<div class="col-md-8">
			<div class="card">
				<div class="card-header" data-background-color="purple">
					<h4 class="title">Quỳnh Trần</h4>
					<p class="category">Khách hàng</p>
				</div>
				<div class="card-content">
					<form>
						<div class="row">
							<div class="col-md-5">
								<div class="form-group label-floating">
									<label class="control-label">Company (disabled)</label>
									<input type="text" class="form-control">
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group label-floating">
									<label class="control-label">Username</label>
									<input type="text" class="form-control" >
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group label-floating">
									<label class="control-label">Email address</label>
									<input type="email" class="form-control" >
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-6">
								<div class="form-group label-floating">
									<label class="control-label">Fist Name</label>
									<input type="text" class="form-control" >
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group label-floating">
									<label class="control-label">Last Name</label>
									<input type="text" class="form-control" >
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-12">
								<div class="form-group label-floating">
									<label class="control-label">Adress</label>
									<input type="text" class="form-control" >
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-4">
								<div class="form-group label-floating">
									<label class="control-label">City</label>
									<input type="text" class="form-control" >
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group label-floating">
									<label class="control-label">Country</label>
									<input type="text" class="form-control" >
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group label-floating">
									<label class="control-label">Postal Code</label>
									<input type="text" class="form-control" >
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>About Me</label>
									<div class="form-group label-floating">
										<label class="control-label"> Lamborghini Mercy, Your chick she so thirsty, I'm in that two seat Lambo.</label>
										<textarea class="form-control" rows="5"></textarea>
									</div>
								</div>
							</div>
						</div>

						<button type="submit" class="btn btn-primary pull-right">Update Profile</button>
						<div class="clearfix"></div>
					</form>
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="card card-profile">
				<div class="card-avatar">
					<a href="#pablo">
						<img class="img" src="/assets/img/faces/marc.jpg" />
					</a>
				</div>

				<div class="content">
					<h6 class="category text-gray">CEO / Co-Founder</h6>
					<h4 class="card-title">Alec Thompson</h4>
					<p class="card-content">
						Don't be scared of the truth because we need to restart the human foundation in truth And I love you like Kanye loves Kanye I love Rick Owens’ bed design but the back is...
					</p>
					<a href="#pablo" class="btn btn-primary btn-round">Follow</a>
				</div>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>