<?php $__env->startSection('content'); ?>
<style type="text/css">
	.detail,
	.title {
		background: white;
		border: 1px solid #ccc;
		padding: 15px 15px 15px 25px;
		border-radius: 5px;
	}
	input,
	select{
		width: 100%;
		height: 50px;
		color: #555;
		border: 1px solid #ccc;
		border-radius: 3px;
		padding-left: 15px;
	}
	label{
		margin-top: 15px;
		font-weight: bold;
	}
</style>
<div class="container-fluid">
	<form action="/admin/user/save" method="POST">
		<div class="title">
			<div class="row">
				<div class="col-md-6 ">
					<h4>Thông tin vé: <strong><?php echo e($ticket->seat_id); ?></strong></h4>
					<a href="/ticket/info/<?php echo e(base64_encode('ticket_id='.$ticket->id)); ?>">Xem trên web</a>
				</div>
				<div class="col-md-6 text-right">
					<?php if($ticket->status == 'complete' || $ticket->status == 'book' || $ticket->status == 'paid' || $ticket->status == 'part-paid' ): ?>
					<button type="button" class="btn btn-success" onclick="print_ticket()"><i class="fa fa-print"></i> In vé</button>
					<?php endif; ?>
					<?php if(($ticket->status == 'book' || $ticket->status == 'part-paid') && $total_fund >= $ticket->total ): ?>
					<button type="button" class="btn btn-success" data-toggle="modal" data-target="#pay" >Thanh toán</button>
					<?php endif; ?>
					<?php if($ticket->status == 'book' ): ?>
					<button type="button" class="btn btn-warning"  data-toggle="modal" data-target="#cancel" >Hủy</button>
					<?php endif; ?>
					<button type="button" class="btn btn-danger"  data-toggle="modal" data-target="#delete" >Xóa</button>
					<?php if($ticket->status == 'cancel' ): ?>
					<!-- <button type="button" class="btn btn-success"  data-toggle="modal" data-target="#rebook" >Đăng ký lại</button> -->
					<?php endif; ?>
				</div>

			</div>
		</div>
		<br>
		<div class="detail" id="detail">
			<div class="row">
				<div class="col-md-8">
					<h4><strong>Thông tin thanh toán</strong></h4>
					<div class="row">
						<div class="col-md-5">
							<p>Trạng thái</p>
							<p style="color: green"><strong><?php echo e($status[$ticket->status]); ?></strong></p>
							<?php if($ticket->status == 'part-paid'): ?>
							<ul>
								<li><strong> Số tiền còn lại <?php echo e($ticket->total - $ticket->paid); ?> </strong></li>
							</ul>
							<?php endif; ?>
							<br>
							<hr>
							<p>Phương thức thanh toán</p>
							<ul>
								<li><strong><?php if($ticket->payment_method == 'bank'): ?> Chuyển khoản <?php elseif($ticket->payment_method == 'direct'): ?> Giao dịch trực tiếp tại văn phòng <?php elseif($ticket->payment_method == 'ship'): ?> Giao vé tận nhà <?php endif; ?></strong></li>
							</ul>
							<?php if($ticket->payment_method == 'ship'): ?>
							<p>Địa chỉ giao vé: </p>
							<ul>
								<li><strong><?php echo e($ticket->ship_address); ?> </strong></li>
							</ul>
							<?php endif; ?>
							<br>
						</div>
						<div class="col-md-7">
							<div class="price" style="border: 1px solid #ccc; padding: 20px; border-radius: 5px ">
								<?php if($ticket->count_adult > 0 ): ?>
								<div class="row">
									<div class="col-md-6">
										<p><?php echo e($ticket->count_adult); ?>x Người lớn: </p>
									</div>
									<div class="col-md-6 text-right">
										<p><strong  class="money"> <?php echo e($ticket->price_adult * $ticket->count_adult); ?> đ</strong></p>
									</div>
								</div>
								<?php endif; ?>
								<?php if($ticket->count_children > 0 ): ?>
								<div class="row">
									<div class="col-md-6">
										<p><?php echo e($ticket->count_children); ?>x trẻ em: </p>
									</div>
									<div class="col-md-6 text-right">
										<p><strong  class="money"><?php echo e($ticket->price_children * $ticket->count_children); ?> đ</strong></p>
									</div>
								</div>
								<?php endif; ?>
								<?php if($ticket->count_baby > 0 ): ?>
								<div class="row">
									<div class="col-md-6">
										<p><?php echo e($ticket->count_baby); ?>x trẻ sơ sinh: </p>
									</div>
									<div class="col-md-6 text-right">
										<p><strong class="money"><?php echo e($ticket->price_baby  * $ticket->count_baby); ?> đ</strong></p>
									</div>
								</div>
								<?php endif; ?>
								<?php if($ticket->count_adult > 0 ): ?>
								<div class="row">
									<div class="col-md-6">
										<p><?php echo e($ticket->count_adult); ?>x dịch vụ người lớn: </p>
									</div>
									<div class="col-md-6 text-right">
										<p><strong class="money"><?php echo e($ticket->service_adult  * $ticket->count_adult); ?> đ</strong></p>
									</div>
								</div>
								<?php endif; ?>
								<?php if($ticket->count_children > 0 ): ?>
								<div class="row">
									<div class="col-md-6">
										<p><?php echo e($ticket->count_children); ?>x dịch vụ trẻ em: </p>
									</div>
									<div class="col-md-6 text-right">
										<p><strong  class="money"><?php echo e($ticket->service_children  * $ticket->count_children); ?> đ</strong></p>
									</div>
								</div>
								<?php endif; ?>
								<?php if($ticket->count_baby > 0 ): ?>
								<div class="row">
									<div class="col-md-6">
										<p><?php echo e($ticket->count_baby); ?>x dịch vụ trẻ sơ sinh: </p>
									</div>
									<div class="col-md-6 text-right">
										<p><strong  class="money"><?php echo e($ticket->service_baby  * $ticket->count_baby); ?> đ</strong></p>
									</div>
								</div>
								<?php endif; ?>
								<div class="row">
									<div class="col-md-6">
										<p>Giá tất cả:</p>
									</div>
									<div class="col-md-6 text-right">
										<p><strong  class="money"><?php echo e($ticket->total); ?> đ</strong></p>
									</div>
								</div>
								<div class="row">
									<div class="col-md-6">
										<p>Giá khuyến mãi: </p>
									</div>
									<div class="col-md-6 text-right">
										<p><strong  class="money"><?php echo e($ticket->gift); ?> đ</strong></p>
									</div>
								</div>

								<hr>
								<div class="row">
									<div class="col-md-6">
										<h4>Giá thanh toán: </h4>

									</div>
									<div class="col-md-6 text-right">
										<h4><strong  class="money"><?php echo e($ticket->total); ?> đ</strong></h4>
									</div>
								</div>
							</div>
						</div>
					</div>
					<br>
					<h4><strong>Thông tin chuyến bay</strong></h4>
					
						<?php $__currentLoopData = $ticket->flights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $flight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="flight no-margin no-padding">
							<div class="form-data">
								<div class="form-header">
									<h4>
										<?php if($flight->type == 'first'): ?>
										<i class="material-icons" style="margin-top: -8px">flight_takeoff</i>
										<?php else: ?>
										<i class="material-icons reverse" style="margin-top: -8px">flight_takeoff</i>
										<?php endif; ?>
										&nbsp; <span class="place_replace"><?php echo e($flight->start_place); ?></span>
										<small class="text-white">&nbsp;&nbsp;<i class="fa fa-long-arrow-right" aria-hidden="true"></i>&nbsp;&nbsp;1g 12 phút&nbsp;&nbsp;<i class="fa fa-long-arrow-right" aria-hidden="true"></i>&nbsp;&nbsp;
										</small> 
										<span class="place_replace"><?php echo e($flight->end_place); ?></span>
										<a class="detail-more" data-toggle="collapse" data-target="#id_flight_<?php echo e($flight->type); ?>">Xem chi tiết</a>
									</h4>

								</div>
								<div class="form-body">

									<div class="row">
										<div class="col-xs-4 text-right">
											<h3 class="no-margin"><strong><?php echo e(substr($flight->start_time, 11, 5)); ?></strong></h3>
											<h3 class="no-margin"><small><?php echo e(substr($flight->start_time, 0, 10)); ?></small></h3>
											<p class="place_replace"><?php echo e($flight->start_place); ?></p>
										</div>
										<div class="col-xs-3" style="margin-top: 5px;display: flex;">
											<i class="fa fa-long-arrow-right pull-left" style="margin-top: 20px"></i>
											<div class="text-center">
												<img  src="https://daisycon.io/images/airline/?width=100&amp;height=30&amp;color=ffffff&amp;iata=<?php echo e($flight->brand); ?>" width="100" height="30">
												<p class="no-margin"><?php if($flight->stop_num == 0): ?> Bay Thẳng <?php else: ?> <?php echo e($flight->stop_num); ?> trạm dừng <?php endif; ?></p>
											</div>

											<i class="fa fa-long-arrow-right pull-right" style="margin-top: 20px"></i>
										</div>
										<div class="col-xs-4">
											<h3 class="no-margin"><strong><?php echo e(substr($flight->end_time, 11, 5)); ?></strong></h3>
											<h3 class="no-margin"><small><?php echo e(substr($flight->start_time, 0, 10)); ?></small></h3>
											<p class="place_replace"><?php echo e($flight->end_place); ?></p>
										</div>
									</div>
									<div class="collapse" id="id_flight_<?php echo e($flight->type); ?>">
										<?php $__currentLoopData = $flight->turn->AvailFlt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index2 => $turn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<hr style="margin: 8px">
										<div>
											<div style="width: 20%" class="inline">
												<img src="https://daisycon.io/images/airline/?width=100&height=50&color=ffffff&iata=<?php echo e($turn->AirV); ?>" width="100" height="50" />
											</div>
											<div style="width: 25%" class="inline">
												<br>
												<p>Từ: <strong><span class="place_replace"><?php echo e($turn->StartAirp); ?></span></strong></p>
												<p><strong><?php echo e($turn->StartDt); ?> </strong><small><?php echo e($turn->StartTm); ?></small></p>
											</div>
											<div style="width: 25%" class="inline">
												<br>
												<p>Từ: <strong><span class="place_replace"><?php echo e($turn->EndAirp); ?></span></strong></p>
												<p><strong><?php echo e($turn->EndDt); ?> </strong><small><?php echo e($turn->EndTm); ?></small></p>
											</div>
											<div style="width: 30%" class="inline">
												<p>Mã máy bay: <strong><?php echo e($turn->Equip); ?></strong></p>
												<p>Số hiệu chuyến bay: <strong><?php echo e($turn->FltNum); ?></strong></p>
											</div>
											<div style="clear: both"></div>
										</div>

										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>

								</div>           
							</div>
						</div>
						<br>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				</div>

				<div class="col-md-4">
					<h4><strong>Thông tin hành khách</strong></h4>
					<p><strong>Hành khách</strong></p>
					<ul>
						<?php $__currentLoopData = $ticket->passengers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $passenger): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li>
							<?php if($passenger->type == 'ADT'): ?>
							<?php if($passenger->sex == 'M'): ?>
							<span >Ông</span>
							<?php else: ?>
							<span> Bà </span>
							<?php endif; ?>

							<span> <?php echo e($passenger->first_name); ?> <?php echo e($passenger->last_name); ?> (<?php echo e($passenger->age); ?> tuổi)</span>
							<?php elseif($passenger->type == 'CHD'): ?>
							<span>Trẻ em: <?php echo e($passenger->first_name); ?> <?php echo e($passenger->last_name); ?> (<?php echo e($passenger->age); ?> tuổi <?php if($passenger->sex == 'M'): ?> - con trai <?php else: ?> con gái <?php endif; ?>)</span>
							<?php elseif($passenger->type == 'INF'): ?>
							<span>Trẻ sơ sinh: <?php echo e($passenger->first_name); ?> <?php echo e($passenger->last_name); ?> (sinh ngày <?php echo e($passenger->age); ?> <?php if($passenger->sex == 'M'): ?> - con trai <?php else: ?> con gái <?php endif; ?>)</span>
							<?php endif; ?>
						</li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
					<hr>
					<p><strong>Liên hệ</strong></p>
					<ul>
						<li>Liên lạc : <?php if($ticket->contact_sex == 'male'): ?><strong> Ông <?php else: ?><strong> Bà <?php endif; ?> <?php echo e($ticket->contact_name); ?></strong></li>
						<li>Địa chỉ : <strong><?php echo e($ticket->contact_address); ?></strong></li>
						<li>Số điện thoại : <strong><a href="tel:<?php echo e($ticket->contact_phone); ?>"> <?php echo e($ticket->contact_phone); ?></a></strong></li>
						<li>Email : <strong><a href="mailto:<?php echo e($ticket->contact_email); ?>"> <?php echo e($ticket->contact_email); ?></a></strong></li>
					</ul>
					<?php if($ticket->is_bill): ?>
					<p><strong>Thông tin hóa đơn</strong></p>
					<ul>
						<li>Công ty: <?php echo e($ticket->bill_company_name); ?></li>
						<li>Mã số thuế: <?php echo e($ticket->bill_tax_number); ?></li>
						<li>Thành phố: <?php echo e($ticket->bill_city); ?></li>
						<li>Địa chỉ: <?php echo e($ticket->bill_address); ?></li>
						<li>Địa chỉ nhận hóa đơn: <?php echo e($ticket->bill_address_receive); ?></li>
					</ul>
					<?php endif; ?>

				</div>
			</div>
			<br>

		</div>
		<?php if($ticket->user_id): ?>
		<br>
		<div class="detail">
			<h4><strong>Thông tin tài khoản đặt vé</strong></h4>
			<div class="row">
				<div class="col-md-3">
					<p>Tên</p>
					<p><strong><a href="/admin/user/<?php echo e($staff->id); ?>"><?php echo e($staff->name); ?></a></strong></p>
				</div>
				<div class="col-md-3">
					<p>Chức vụ</p>
					<p><strong><?php if($staff->role == '1'): ?> Quản trị <?php elseif($staff->role == '2'): ?> Đại lý cấp 2 <?php elseif($staff->role == '3'): ?> Nhân viên <?php elseif($staff->role == '4'): ?> Khách hàng <?php endif; ?> </strong></p>
				</div>
				<div class="col-md-3">
					<p>Email liên hệ</p>
					<p><strong><?php echo e($staff->email); ?></strong></p>
				</div>
				<div class="col-md-3">
					<p>Quỹ tiền</p>
					<p><strong><?php echo e($total_fund); ?> vnđ</strong></p>
				</div>
			</div>
		</div>
		<?php endif; ?>
	</form>
</div>
<script type="text/javascript">

	function print_ticket() {
		var printContents = document.getElementById('detail').innerHTML;
		console.log(printContents);
		var originalContents = document.body.innerHTML;

		document.body.innerHTML = printContents;

		window.print();

		document.body.innerHTML = originalContents;
	}

	var airports = [];
	$.getJSON("/airport.json", function(data){

		$.each(data, function(index, value){
			var key = value.substring(value.lastIndexOf("(")+1,value.lastIndexOf(")"));
			airports[key] = value;
		})
	})
	setTimeout(function() {
		$('.place_replace').each(function(){
			console.log($(this).html());
			$(this).html(airports[$(this).html()]);
		})
	}, 1000);

</script>
<?php $__env->stopSection(); ?>
<div id="cancel" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<form action="/admin/change_status">
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Hủy vé</h4>
				</div>
				<div class="modal-body">
					<p>Xin hãy nhập lý do</p>
					<div class="form-group label-floating">
						<input type="hidden" name="type" value="cancel">
						<input type="hidden" name="id" value="<?php echo e($ticket->id); ?>">
						<label class="control-label">Lý do</label>
						<input type="text" name="reason" class="form-control" placeholder="" required minlength="10">
					</div>
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-warning">Hủy</button>
					<button type="button" class="btn btn-default" data-dismiss="modal">Đóng</button>
				</div>
			</div>
		</form>
	</div>
</div>



<!-- Modal -->
<div id="pay" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<form action="/admin/change_status">
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Thanh toán</h4>
				</div>
				<div class="modal-body">
					<p>Xin hãy nhập số tiền thanh toán vào đây (vnd)</p>
					<div class="form-group label-floating">
						<input type="hidden" name="type" value="pay">
						<input type="hidden" name="id" value="<?php echo e($ticket->id); ?>">
						<label class="control-label">Số tiền thanh toán</label>
						<input type="number" name="pay_amount" class="form-control" value="<?php echo e($ticket->total); ?>" required id="pay_amount">
					</div>
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-success" >Đồng ý</button>
					<button type="button" class="btn btn-default" data-dismiss="modal">Đóng</button>
				</div>
			</div>
		</form>
	</div>
</div>

<div id="delete" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<form action="/admin/change_status">
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<input type="hidden" name="type" value="delete">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<input type="hidden" name="id" value="<?php echo e($ticket->id); ?>">
					<h4 class="modal-title">Xóa </h4>
				</div>
				<div class="modal-body">
					<p>Bạn chắc chắn muốn xóa</p>
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-danger">Xóa</button>
					<button type="button" class="btn btn-default" data-dismiss="modal">Đóng</button>
				</div>
			</div>
		</form>
	</div>
</div>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>