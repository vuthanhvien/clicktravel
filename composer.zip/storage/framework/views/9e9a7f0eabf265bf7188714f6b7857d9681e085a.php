<!doctype html>
<html lang="en">
	<?php $__env->startComponent('admin.component.head'); ?>
	<?php echo $__env->renderComponent(); ?>

<body>

	<div class="wrapper">
	<?php $__env->startComponent('admin.component.sidebar'); ?>
	<?php echo $__env->renderComponent(); ?>


	   <div class="main-panel">
			
	   		<?php $__env->startComponent('admin.component.nav'); ?>
			<?php echo $__env->renderComponent(); ?>

	        <div class="content" style="margin-top: 0px;">
	        <?php echo $__env->yieldContent('content'); ?>
	        </div>
	    </div>
	</div>
</body>

	<?php $__env->startComponent('admin.component.footer'); ?>
	<?php echo $__env->renderComponent(); ?>

</html>
