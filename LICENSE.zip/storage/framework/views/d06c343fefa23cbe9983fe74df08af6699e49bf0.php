<?php $__env->startSection('content'); ?>
    
<div class="container text-center" style="min-height: calc(80vh)">
<br>
<br>
<br>
<br>
<br>
<h1 style="font-size: 80px; font-weight: 700">404 not found</h1>
<br>
<h4>Trang bạn tìm kiếm không tồn tại</h4>
<a href="/" class="btn btn-primary"><i class="fa fa-chevron-left" aria-hidden="true"></i> &nbsp; Quay lại trang chủ</a>
<br>
<br>
<br>
</div>

<?php $__env->startComponent('component.footer'); ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>