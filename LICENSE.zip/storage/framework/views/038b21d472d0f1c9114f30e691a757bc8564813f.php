        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse" style="margin-top: 14px;">
                        <i class="fa fa-bars fa-lg"></i>
                    </button>

                    <a class="logo" style="padding: 10px 50px 0 15px;" href="<?php echo e(url('/')); ?>">
                        <img height="60" src="/img/clicktravel-logo.png" style="margin-top: 3px">
                    </a>
                </div>
                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-left no-margin">
                        <li  class="item-head <?php echo e(( request()->is('ticket*') || request()->is('/') )? 'active' : ''); ?>"><a href="<?php echo e(url('ticket')); ?>" >Vé nội địa và quốc tế</a></li>
                        <li  class="item-head <?php echo e(request()->is('hotel*') ? 'active' : ''); ?>"><a href="<?php echo e(url('hotel')); ?>" >Khách sạn</a></li>
                        <li  class="item-head <?php echo e(request()->is('visa*') ? 'active' : ''); ?>"><a href="<?php echo e(url('visa')); ?>" >Visa/Pastport</a></li>
                        <li  class="item-head <?php echo e(request()->is('promotion*') ? 'active' : ''); ?>"><a href="<?php echo e(url('promotion')); ?>" >Khuyến mãi</a></li>
                        <li  class="item-head <?php echo e(request()->is('payment*') ? 'active' : ''); ?>"><a href="<?php echo e(url('payment')); ?>" >Thanh toán </a></li>
                        
                    </ul>
                    <ul class="nav navbar-nav navbar-right no-margin">
                    <?php if(Auth::guest()): ?>
                        <li><a class="btn btn-primary hidden-xs" href="<?php echo e(url('login')); ?>">Đăng nhập</a></li>
                        <li><a class="hidden-sm hidden-md hidden-lg" href="<?php echo e(url('payment')); ?>"><i class="fa fa-sign-in"></i> &nbsp;Đăng nhập</a></li>

                        <?php else: ?>

                        <li><a class="hidden-sm hidden-md hidden-lg" href="/user"><i class="fa fa-cog"></i> &nbsp;&nbsp;Tài khoản của bạn </a></li>
                        <li><a class="hidden-sm hidden-md hidden-lg" href="/user/ticket"><i class="fa fa-ticket"></i> &nbsp;&nbsp;Vé của bạn </a></li>
                        <?php if(Auth::user()->role == 1 ||  Auth::user()->role == 2): ?>
                        <li><a class="hidden-sm hidden-md hidden-lg"  href="/admin"><i class="fa fa-tachometer"></i> &nbsp;&nbsp;Trang quản lý </a></li>
                        <?php endif; ?>
                        <li>
                            <a  class="hidden-sm hidden-md hidden-lg"  href="<?php echo e(route('logout')); ?>"onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <i class="fa fa-sign-out"></i> &nbsp;&nbsp;Đăng xuất 
                            </a>
                        </li>


                        <li class="dropdown hidden-xs">
                            <a class="btn btn-primary" href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                            </a>

                            <ul class="dropdown-menu login-section" role="menu">

                                <li><a href="/user"><i class="fa fa-cog"></i> &nbsp;&nbsp;Tài khoản của bạn </a></li>
                                <li><a href="/user/ticket"><i class="fa fa-ticket"></i> &nbsp;&nbsp;Vé của bạn </a></li>
                                <?php if(Auth::user()->role == 1 ||  Auth::user()->role == 2): ?>
                                <li><a href="/admin"><i class="fa fa-tachometer"></i> &nbsp;&nbsp;Trang quản lý </a></li>
                                <?php endif; ?>
                                <li>
                                    <a href="<?php echo e(route('logout')); ?>"onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                        <i class="fa fa-sign-out"></i> &nbsp;&nbsp;Đăng xuất 
                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo e(csrf_field()); ?>

                                    </form>
                                </li>
                            </ul>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
            
        </nav>