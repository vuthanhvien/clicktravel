@extends('layouts.app')

@section('content')
    
<div class="container text-center" style="min-height: calc(80vh)">
<br>
<br>
<br>
<br>
<br>
<h1 style="font-size: 80px; font-weight: 700">Hẹn gặp lại sau</h1>
<br>
<h4>Chúng tôi đang phát triển chức năng này</h4>
<h4>Xin gặp lại các bạn sau</h4>
<a href="/" class="btn btn-primary"><i class="fa fa-chevron-left" aria-hidden="true"></i> &nbsp; Quay lại trang chủ</a>
<br>
<br>
<br>
</div>

@component('component.footer')
@endcomponent

@endsection
