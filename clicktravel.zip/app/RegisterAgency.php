<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RegisterAgency extends Model
{
   	protected $table = 'agency_register';
    //
}
