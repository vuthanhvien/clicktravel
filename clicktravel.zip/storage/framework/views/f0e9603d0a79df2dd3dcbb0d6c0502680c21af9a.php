<?php $__env->startSection('content'); ?>

<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
					<div class="row">
						<div class="col-xs-5"><h4 class="title">Thông tin đăng ký</h4>
						</div>
						<div class="col-xs-7 text-right">
							<span>
								<ul class="pagination pull-right" style="margin:0; color: #555">
									<?php if( $agency_register->currentPage() != 1): ?> 
										<li><a href="/admin/agency_register?s=<?php echo e($search); ?>&page=1">Trang đầu</a></li>
									<?php else: ?>
										<li class="disabled"><a href="/admin/agency_register?s=<?php echo e($search); ?>&page=1">Trang đầu</a></li>

									<?php endif; ?>
									<?php if( $agency_register->currentPage() == $agency_register->lastPage()  && $agency_register->currentPage() > 4): ?>
										<li><a href="/admin/agency_register?s=<?php echo e($search); ?>&page=<?php echo e($agency_register->currentPage() - 4); ?>"><?php echo e($agency_register->currentPage() - 4); ?></a></li>
									<?php endif; ?>
									<?php if(( $agency_register->currentPage() == $agency_register->lastPage() - 1 ||  $agency_register->currentPage() == $agency_register->lastPage()) &&   $agency_register->currentPage() > 3): ?> 
										<li><a href="/admin/agency_register?s=<?php echo e($search); ?>&page=<?php echo e($agency_register->currentPage() - 3); ?>"><?php echo e($agency_register->currentPage() - 3); ?></a></li>
									<?php endif; ?>
									<?php if( $agency_register->currentPage() > 2): ?> 
										<li><a href="/admin/agency_register?s=<?php echo e($search); ?>&page=<?php echo e($agency_register->currentPage() - 2); ?>"><?php echo e($agency_register->currentPage() - 2); ?></a></li>
									<?php endif; ?>
									<?php if( $agency_register->currentPage() > 1): ?> 
										<li><a href="/admin/agency_register?s=<?php echo e($search); ?>&page=<?php echo e($agency_register->currentPage() - 1); ?>"><?php echo e($agency_register->currentPage() - 1); ?></a></li>
									<?php endif; ?>

									<li  class="active"><a  href="#"><?php echo e($agency_register->currentPage()); ?></a></li>

									<?php if( $agency_register->currentPage() < $agency_register->lastPage()): ?> 
										<li><a href="/admin/agency_register?s=<?php echo e($search); ?>&page=<?php echo e($agency_register->currentPage() + 1); ?>"><?php echo e($agency_register->currentPage() + 1); ?></a></li>
									<?php endif; ?>
									<?php if( $agency_register->currentPage() < $agency_register->lastPage() - 1 ): ?> 
										<li><a href="/admin/agency_register?s=<?php echo e($search); ?>&page=<?php echo e($agency_register->currentPage() + 2); ?>"><?php echo e($agency_register->currentPage() + 2); ?></a></li>
									<?php endif; ?>
									<?php if(( $agency_register->currentPage() == 2 ||  $agency_register->currentPage() == 1) && $agency_register->lastPage() > 3 ): ?>
										<li><a href="/admin/agency_register?s=<?php echo e($search); ?>&page=<?php echo e($agency_register->currentPage() + 3); ?>"><?php echo e($agency_register->currentPage() + 3); ?></a></li>
									<?php endif; ?>
									<?php if( $agency_register->currentPage() == 1 && $agency_register->lastPage() > 4): ?> 
										<li><a href="/admin/agency_register?s=<?php echo e($search); ?>&page=<?php echo e($agency_register->currentPage() + 4); ?>"><?php echo e($agency_register->currentPage() + 4); ?></a></li>
									<?php endif; ?>
									<?php if( $agency_register->currentPage() != $agency_register->lastPage() ): ?> 
										<li><a href="/admin/agency_register?s=<?php echo e($search); ?>&page=<?php echo e($agency_register->lastPage()); ?>">Trang cuối</a></li>
									<?php else: ?>
										<li class="disabled"><a href="/admin/agency_register?s=<?php echo e($search); ?>&page=<?php echo e($agency_register->lastPage()); ?>">Trang cuối</a></li>
									<?php endif; ?>
								</ul>
								<style type="text/css">
									.pagination a{
										color: #555;
									}
									.card [data-background-color] a{
										color: initial;
									}
									.pagination li.active a{
										color: white;
									}
									.pagination li.disabled a{
										pointer-events: none;
									}
									.pagination li.disabled a{
										color: #ccc;
									}
								</style>
							</span>
							<form action="/admin/agency_register">
								<div class="pull-right" style="position: relative;" >
									<input placeholder="Tìm kiếm" name="s" value="<?php echo e($search); ?>" style="color:#555; padding-left: 15px;   height: 34px;border: 0;border-radius: 5px;margin-right: 17px;" onkeydown="if (event.keyCode == 13) { this.form.submit(); return false; }">
									<i style="position: absolute;color: #555;right: 25px;top: 10px;" class="fa fa-search"></i>
								</div>
							</form>
						</div>
					</div>
				</div>
				<div class="card-content table-responsive">
					<table class="table table-border" id="table">
						<thead class="text-primary">
							<th>Tên</th>
							<th>Họ</th>
							<th>Số điện thoại</th>
							<th>Địa chỉ</th>
							<th>Trạng thái</th>
							<th>Thao tác</th>
						</thead>
						<tbody>
							<?php $__currentLoopData = $agency_register; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agency_register): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($agency_register->first_name); ?></td>
								<td><?php echo e($agency_register->last_name); ?></td>
								<td><?php echo e($agency_register->phone); ?></td>
								<td><?php echo e($agency_register->address); ?></td>
								<td><?php echo e($agency_register->status); ?></td>
								<td>
									<a href="/admin/agency_register/<?php echo e($agency_register->id); ?>">Chi tiết</a>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


						</tbody>
					</table>

				</div>
			</div>


		</div>

	</div>
</div>
<script type="text/javascript">
		// $('#table').DataTable({
		// 	 "ajax": '/admin/passenger_data'
		// });
	</script>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>