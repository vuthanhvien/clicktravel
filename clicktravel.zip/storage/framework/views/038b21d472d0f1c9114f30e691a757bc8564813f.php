        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse" style="margin-top: 27px;">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <a class="logo" style="padding-top: 5px;" href="<?php echo e(url('/')); ?>">
                        <img width="110" src="/img/clicktravel-logo.png">
                    </a>
                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        <li><a href="<?php echo e(url('ticket')); ?>"><i class="fa fa-ticket"></i> &nbsp;Đăng ký vé máy bay</a></li>
                        <li><a href="<?php echo e(url('payment')); ?>"><i class="fa fa-credit-card"></i> &nbsp;Thanh toán &nbsp;&nbsp;&nbsp;&nbsp;</a></li>
                        <!-- <li><a href=""></a></li> -->
                        <?php if(Auth::guest()): ?>
                        <!-- <li><a href="<?php echo e(route('login')); ?>">Login</a></li> -->
                        <li><a class="btn btn-primary hidden-xs" href="<?php echo e(url('login')); ?>">Đăng nhập</a></li>
                        <!-- <li><a class="btn btn-primary hidden-xs" data-toggle="modal" data-target="#login" href="#">Đăng nhập</a></li> -->
                        <li><a class="hidden-sm hidden-md hidden-lg" href="<?php echo e(url('payment')); ?>"><i class="fa fa-sign-in"></i> &nbsp;Đăng nhập</a></li>

                        <!-- <li><a href="<?php echo e(route('register')); ?>">Register</a></li> -->
                        <?php else: ?>
                        <li class="dropdown">
                            <a class="btn btn-primary" href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                            </a>

                            <ul class="dropdown-menu login-section" role="menu">

                                <li><a href="/user"><i class="fa fa-cog"></i> &nbsp;&nbsp;Tài khoản của bạn </a></li>
                                <li><a href="/user/ticket"><i class="fa fa-ticket"></i> &nbsp;&nbsp;Vé của bạn </a></li>
                                <!-- <li><a href="/user/history"><i class="fa fa-history"></i> &nbsp;&nbsp;Lịch sử </a></li> -->
                                <?php if(Auth::user()->role == 1 ||  Auth::user()->role == 2): ?>
                                <li><a href="/admin"><i class="fa fa-tachometer"></i> &nbsp;&nbsp;Trang quản lý </a></li>
                                <?php endif; ?>
                                <li>
                                    <a href="<?php echo e(route('logout')); ?>"onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                        <i class="fa fa-sign-out"></i> &nbsp;&nbsp;Đăng xuất 
                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo e(csrf_field()); ?>

                                    </form>
                                </li>
                            </ul>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
            
        </nav>