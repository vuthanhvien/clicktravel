<?php $__env->startSection('content'); ?>
<style type="text/css">
	.detail,
	.title {
		background: white;
		border: 1px solid #ccc;
		padding: 15px 15px 15px 25px;
		border-radius: 5px;
	}
	input,
	select{
		width: 100%;
		height: 50px;
		color: #555;
		border: 1px solid #ccc;
		border-radius: 3px;
		padding-left: 15px;
	}
	label{
		font-weight: bold;
	}
</style>
<div class="container-fluid">
	<form action="/admin/contact/save" method="POST">
                    <?php echo e(csrf_field()); ?>

		<input type="hidden" name="id" value="<?php echo e($contact->id); ?>">
		<input type="hidden" name="email" value="<?php echo e($contact->email); ?>">
		<div class="title">
			<div class="row">
				<div class="col-md-12 ">
					<h4><strong>Nội dung của <?php echo e($contact->name); ?> </strong>  < <?php echo e($contact->email); ?> > <small><?php echo e($contact->created_at); ?></small></h4>
				</div>
			</div>
		</div>
		<br>
		<div class="detail">
		<?php if( $contact->transition_id): ?>
			<div class="fight-detail">
				<?php echo e($contact->transition_id); ?>

			</div>
			<hr>
		<?php endif; ?>
			<div class="row">
				<div class="col-md-2 text-right"><label><?php echo e($contact->name); ?></label></div>
				<div class="col-md-8 ">
				<div  style="border: 1px solid #ccc; min-height: 100px; padding-top: 15px; padding-left: 15px; border-radius: 5px;">
					<label>Nội dung</label>

					<p><?php echo e($contact->memo); ?></p>
				</div>
				</div>
				
			</div>
			
			<br>
			<div class="row">
				<div class="col-md-8 col-md-offset-2"  >
					<textarea rows="5" name="content" style="border: 1px solid #ccc; min-height: 100px; padding-top: 15px; width: 100%; padding-left: 15px;" placeholder="Hãy nhập nội dung, nội dung này sẽ được gửi tới email của <?php echo e($contact->name); ?>"></textarea>					
				</div>
				
			</div>
			<br>
			<div class="row">
				<div class="col-md-10 text-right">
					<button class="btn btn-success">Gửi</button>
				</div>
			</div>

		</div>
	</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>