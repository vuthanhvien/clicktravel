<?php $__env->startSection('content'); ?>

<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
							<div class="row">
						<div class="col-xs-5"><h4 class="title">Thông tin khách hàng</h4>
						</div>
						<div class="col-xs-7 text-right">
							<span>
								<ul class="pagination pull-right" style="margin:0; color: #555">
									<?php if( $tickets->currentPage() != 1): ?> 
										<li><a href="/admin/ticket?s=<?php echo e($search); ?>&page=1">Trang đầu</a></li>
									<?php else: ?>
										<li class="disabled"><a href="/admin/ticket?s=<?php echo e($search); ?>&page=1">Trang đầu</a></li>

									<?php endif; ?>
									<?php if( $tickets->currentPage() == $tickets->lastPage()  && $tickets->currentPage() > 4): ?>
										<li><a href="/admin/ticket?s=<?php echo e($search); ?>&page=<?php echo e($tickets->currentPage() - 4); ?>"><?php echo e($tickets->currentPage() - 4); ?></a></li>
									<?php endif; ?>
									<?php if(( $tickets->currentPage() == $tickets->lastPage() - 1 ||  $tickets->currentPage() == $tickets->lastPage()) &&   $tickets->currentPage() > 3): ?> 
										<li><a href="/admin/ticket?s=<?php echo e($search); ?>&page=<?php echo e($tickets->currentPage() - 3); ?>"><?php echo e($tickets->currentPage() - 3); ?></a></li>
									<?php endif; ?>
									<?php if( $tickets->currentPage() > 2): ?> 
										<li><a href="/admin/ticket?s=<?php echo e($search); ?>&page=<?php echo e($tickets->currentPage() - 2); ?>"><?php echo e($tickets->currentPage() - 2); ?></a></li>
									<?php endif; ?>
									<?php if( $tickets->currentPage() > 1): ?> 
										<li><a href="/admin/ticket?s=<?php echo e($search); ?>&page=<?php echo e($tickets->currentPage() - 1); ?>"><?php echo e($tickets->currentPage() - 1); ?></a></li>
									<?php endif; ?>

									<li  class="active"><a  href="#"><?php echo e($tickets->currentPage()); ?></a></li>

									<?php if( $tickets->currentPage() < $tickets->lastPage()): ?> 
										<li><a href="/admin/ticket?s=<?php echo e($search); ?>&page=<?php echo e($tickets->currentPage() + 1); ?>"><?php echo e($tickets->currentPage() + 1); ?></a></li>
									<?php endif; ?>
									<?php if( $tickets->currentPage() < $tickets->lastPage() - 1 ): ?> 
										<li><a href="/admin/ticket?s=<?php echo e($search); ?>&page=<?php echo e($tickets->currentPage() + 2); ?>"><?php echo e($tickets->currentPage() + 2); ?></a></li>
									<?php endif; ?>
									<?php if(( $tickets->currentPage() == 2 ||  $tickets->currentPage() == 1) && $tickets->lastPage() > 3 ): ?>
										<li><a href="/admin/ticket?s=<?php echo e($search); ?>&page=<?php echo e($tickets->currentPage() + 3); ?>"><?php echo e($tickets->currentPage() + 3); ?></a></li>
									<?php endif; ?>
									<?php if( $tickets->currentPage() == 1 && $tickets->lastPage() > 4): ?> 
										<li><a href="/admin/ticket?s=<?php echo e($search); ?>&page=<?php echo e($tickets->currentPage() + 4); ?>"><?php echo e($tickets->currentPage() + 4); ?></a></li>
									<?php endif; ?>
									<?php if( $tickets->currentPage() != $tickets->lastPage() ): ?> 
										<li><a href="/admin/ticket?s=<?php echo e($search); ?>&page=<?php echo e($tickets->lastPage()); ?>">Trang cuối</a></li>
									<?php else: ?>
										<li class="disabled"><a href="/admin/ticket?s=<?php echo e($search); ?>&page=<?php echo e($tickets->lastPage()); ?>">Trang cuối</a></li>
									<?php endif; ?>
								</ul>
								<style type="text/css">
									.pagination a{
										color: #555;
									}
									.card [data-background-color] a{
										color: initial;
									}
									.pagination li.active a{
										color: white;
									}
									.pagination li.disabled a{
										pointer-events: none;
									}
									.pagination li.disabled a{
										color: #ccc;
									}
								</style>
							</span>
							<form action="/admin/ticket">
								<div class="pull-right" style="position: relative;" >
									<input placeholder="Tìm kiếm" name="s" value="<?php echo e($search); ?>" style="color:#555; padding-left: 15px;   height: 34px;border: 0;border-radius: 5px;margin-right: 17px;" onkeydown="if (event.keyCode == 13) { this.form.submit(); return false; }">
									<i style="position: absolute;color: #555;right: 25px;top: 10px;" class="fa fa-search"></i>
								</div>
							</form>
						</div>
					</div>
				</div>
				<div class="card-content table-responsive">
					<table class="table">
						<thead class="text-primary">
							<th>Người đặt</th>
							<th>Mã ghế ngồi</th>
							<th>Mã giao dịch</th>
							<th>Số lượng</th>
							<!-- <th>Điểm đi</th> -->
							<!-- <th>Điểm đến</th> -->
							<th>Khứ hồi / Một chiều</th>
							<th>Giá</th>
							<th>Thao tác</th>
						</thead>
						<tbody>
						<?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($ticket->contact_name); ?></td>
								<td><?php echo e($ticket->seat_id); ?></td>
								<td><?php echo e($ticket->transition_id); ?></td>
								<td><?php echo e($ticket->number); ?></td>
								<!-- <td>Hà Nội, 12:50 07/07/2017</td> -->
								<!-- <td>Hà Nội, 12:50 07/07/2017</td> -->
								<td><?php echo e($ticket->pay_all); ?> <?php echo e($ticket->currency); ?></td>
								<td><?php echo e($ticket->type_flight); ?></td>
								<td class="text-primary"><a href="/admin/ticket/<?php echo e($ticket->id); ?>">Chi tiết	</a></td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>