<?php $__env->startSection('content'); ?>
<style type="text/css">
	.detail,
	.title {
		background: white;
		border: 1px solid #ccc;
		padding: 15px 15px 15px 25px;
		border-radius: 5px;
	}
	input,
	select{
		width: 100%;
		height: 50px;
		color: #555;
		border: 1px solid #ccc;
		border-radius: 3px;
		padding-left: 15px;
	}
	label{
		margin-top: 15px;
		font-weight: bold;
	}
</style>
<div class="container-fluid">
	<form action="/admin/user/save" method="POST">
		<div class="title">
			<div class="row">
				<div class="col-md-6 ">
					<h4>Thông tin vé: <?php echo e($ticket->transition_id); ?></h4>
				</div>
				<div class="col-md-6 text-right">
					<button type="button" class="btn btn-success">Đã thanh toán</button>
					<button type="button" class="btn btn-warning">Hủy</button>
					<button type="button" class="btn btn-danger">Xóa</button>
				</div>
			</div>
		</div>
		<br>
		<div class="detail">
			<div class="row">
				<div class="col-md-7">
					<h4><strong>Thông tin thanh toán</strong></h4>
					<p><strong>Trạng thái</strong></p>
					<p>Đã xác nhận, chờ thanh toán</p>
					<p><strong>Giá</strong></p>
					<p>Giá một người: <?php echo e($ticket->price_one); ?> <?php echo e($ticket->currency); ?></p>
					<p>Giá tất cả: <?php echo e($ticket->price_all); ?> <?php echo e($ticket->currency); ?></p>
					<p>Giá dịch vụ: <?php echo e($ticket->price_service); ?> <?php echo e($ticket->currency); ?></p>
					<p>Tổng giá: <?php echo e($ticket->total); ?> <?php echo e($ticket->currency); ?></p>
					<p>Giá khuyến mãi: -<?php echo e($ticket->gift); ?> <?php echo e($ticket->currency); ?></p>
					<p>Giá thanh toán: <?php echo e($ticket->pay_all); ?> <?php echo e($ticket->currency); ?></p>
					<br>
					<p><strong>Phướng thức thanh toán</strong></p>
					<p><?php if($ticket->payment_method == 'bank'): ?> Chuyển khoản <?php elseif($ticket->payment_method == 'direct'): ?> Giao dịch trực tiếp tại văn phòng <?php elseif($ticket->payment_method == 'ship'): ?> Giao vé tận nhà <?php endif; ?></p>
					<?php if($ticket->payment_method == 'ship'): ?>
					<p>Địa chỉ giao vé: <?php echo e($ticket->ship_address); ?></p>
					<?php endif; ?>
					<br>
					<br>

					<h4><strong>Thông tin chuyến bay</strong></h4>
					
					<div class="modal-detail">
						<?php $__currentLoopData = $ticket->flights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<p><strong><?php if($flight->type == 'go'): ?> Chuyến đi <?php else: ?> Chuyến về <?php endif; ?>  <?php if($flight->turn > 1): ?> <?php echo e($flight->turn); ?> <?php endif; ?> </strong> <?php echo e($flight->start_date); ?></p>

						<div class="first-way">
							<div class="row">
								<div class="col-xs-4 text-right">
									<h3><?php echo e($flight->start_time); ?></h3>
									<p><?php echo e($flight->start_place); ?></p>


								</div>
								<div class="col-xs-3">
									<p class="text-center no-margin" style="width: 85%"> 1g 45 phút</p>
									<div class="line"></div> &nbsp; 
									<i class="fa fa-plane fa-rotate-45"></i>
									<p style="width: 85%; margin: 0; text-align: center"><?php echo e($flight->brand); ?></p>
								</div>
								<div class="col-xs-3">
									<h3><?php echo e($flight->end_time); ?></h3>
									<p><?php echo e($flight->end_place); ?></p>
								</div>

							</div>
						</div>
						<br />
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>

				</div>

				<div class="col-md-5">
					<h4><strong>Thông tin hành khách</strong></h4>
					<p><strong>Hành khách</strong></p>
						<?php $__currentLoopData = $ticket->passengers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $passenger): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<p>
							<?php if($passenger->type == 'adult'): ?>
								<?php if($passenger->sex == 'male'): ?>
									<span >Ông</span>
								<?php else: ?>
									<span> Bà </span>
								<?php endif; ?>

								<span> <?php echo e($passenger->first_name); ?> <?php echo e($passenger->last_name); ?> </span>
							<?php elseif($passenger->type == 'children'): ?>
								<span>Trẻ em: <?php echo e($passenger->first_name); ?> <?php echo e($passenger->last_name); ?> (<?php echo e($passenger->age); ?> tuổi)</span>
								<?php elseif($passenger->type == 'baby'): ?>
								<span>Trẻ sơ sinh: <?php echo e($passenger->first_name); ?> <?php echo e($passenger->last_name); ?> (<?php echo e($passenger->age); ?> tháng tuổi)</span>
							<?php endif; ?>
							</p>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<p><strong>Liên hệ</strong></p>
						<p>Tên liên lạc : <?php if($passenger->sex == 'male'): ?>
									<span >Ông</span>
								<?php else: ?>
									<span> Bà </span>
								<?php endif; ?> 

								<?php echo e($ticket->contact_name); ?></p>
						<p>Địa chỉ : <?php echo e($ticket->contact_address); ?></p>
						<p>Số điện thoại : <?php echo e($ticket->contact_phone); ?></p>
						<p>Email : <?php echo e($ticket->contact_email); ?></p>
						<p></p>
						<p></p>
						<p></p>
						<?php if($ticket->is_bill): ?>
					<p><strong>Thông tin hóa đơn</strong></p>
						<p>Công ty: <?php echo e($ticket->bill_company_name); ?></p>
						<p>Mã số thuế: <?php echo e($ticket->bill_tax_number); ?></p>
						<p>Thành phố: <?php echo e($ticket->bill_city); ?></p>
						<p>Địa chỉ: <?php echo e($ticket->bill_address); ?></p>
						<p>Địa chỉ nhận hóa đơn: <?php echo e($ticket->bill_address_receive); ?></p>
						<?php endif; ?>
					
				</div>
			</div>
			<br>

		</div>
	</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>