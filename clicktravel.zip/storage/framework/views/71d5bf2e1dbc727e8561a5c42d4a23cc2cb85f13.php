<?php echo e($first_name); ?>

<?php echo e($last_name); ?>

<?php echo e($email); ?>

<?php echo e($address); ?>

<?php echo e($phone); ?>

<?php echo e($memo); ?>